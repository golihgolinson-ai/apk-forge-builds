package com.dazed.fishing3d

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import kotlin.math.*

/** Icon-based interface: stick, round buttons, hotbar, money box, fight meter, toast and the backpack screen. */
class Hud {
    class Item(val value: Int, val color: Color)
    val bag = ArrayList<Item>()
    var bagOpen = false
    private val sr = ShapeRenderer(); private val sb = SpriteBatch(); private val font = BitmapFont(); private val gl = GlyphLayout()
    private val panelC = Color(0.08f, 0.1f, 0.18f, 0.88f); private val slotC = Color(0.17f, 0.2f, 0.3f, 0.9f)
    private val white = Color(1f, 1f, 1f, 1f); private val blue = Color(0.2f, 0.55f, 0.95f, 0.9f); private val grey = Color(0.3f, 0.35f, 0.5f, 0.8f)

    private fun jumpB(w: Float, d: Float) = floatArrayOf(w - 250f * d, 90f * d, 40f * d)
    private fun actB(w: Float, d: Float) = floatArrayOf(w - 110f * d, 130f * d, 56f * d)
    private fun bagB(w: Float, d: Float) = floatArrayOf(w - 70f * d, 290f * d, 34f * d)
    private fun inside(b: FloatArray, x: Float, y: Float) = hypot(x - b[0], y - b[1]) <= b[2] * 1.15f
    private fun panel(w: Float, h: Float, d: Float): FloatArray {
        val pw = min(w * 0.7f, 900f * d); val ph = min(h * 0.8f, 520f * d); return floatArrayOf((w - pw) / 2f, (h - ph) / 2f, pw, ph)
    }
    fun total() = bag.sumOf { it.value }

    /** Touch (y from top) -> 3 jump, 4 action, 5 bag, 0 none. */
    fun hit(w: Float, h: Float, d: Float, x: Float, yTop: Float): Int {
        val y = h - yTop
        return when { inside(actB(w, d), x, y) -> 4; inside(jumpB(w, d), x, y) -> 3; inside(bagB(w, d), x, y) -> 5; else -> 0 }
    }
    /** Backpack screen tap -> 1 close, 2 sell, 0 nothing. */
    fun panelHit(w: Float, h: Float, d: Float, x: Float, yTop: Float): Int {
        val y = h - yTop; val p = panel(w, h, d)
        if (hypot(x - (p[0] + p[2] - 34f * d), y - (p[1] + p[3] - 34f * d)) < 34f * d || inside(bagB(w, d), x, y)) return 1
        if (x > p[0] + p[2] / 2f - 130f * d && x < p[0] + p[2] / 2f + 130f * d && y > p[1] + 14f * d && y < p[1] + 66f * d) return 2
        return 0
    }

    private fun rodIcon(cx: Float, cy: Float, s: Float, a: Float) {
        sr.setColor(0.85f, 0.9f, 1f, a); sr.rectLine(cx - s, cy - s, cx + s, cy + s, s * 0.16f)
        sr.setColor(0.3f, 0.35f, 0.6f, a); sr.circle(cx - s * 0.35f, cy - s * 0.35f, s * 0.3f)
        sr.setColor(0.75f, 0.92f, 0.2f, a); sr.rectLine(cx + s, cy + s, cx + s, cy, s * 0.07f)
    }
    private fun knifeIcon(cx: Float, cy: Float, s: Float, a: Float) {
        sr.setColor(0.8f, 0.82f, 0.88f, a); sr.rectLine(cx - s * 0.1f, cy - s * 0.1f, cx + s * 0.9f, cy + s * 0.9f, s * 0.28f)
        sr.setColor(0.2f, 0.2f, 0.25f, a); sr.rectLine(cx - s * 0.9f, cy - s * 0.9f, cx - s * 0.1f, cy - s * 0.1f, s * 0.3f)
    }
    private fun pistolIcon(cx: Float, cy: Float, s: Float, a: Float) {
        sr.setColor(0.7f, 0.72f, 0.78f, a); sr.rect(cx - s, cy, s * 1.8f, s * 0.55f); sr.rect(cx - s * 0.7f, cy - s * 0.8f, s * 0.5f, s * 0.85f)
    }
    private fun dynIcon(cx: Float, cy: Float, s: Float, a: Float) {
        sr.setColor(0.85f, 0.15f, 0.15f, a); sr.rect(cx - s * 0.3f, cy - s * 0.8f, s * 0.6f, s * 1.5f)
        sr.setColor(1f, 1f, 1f, a); sr.rectLine(cx, cy + s * 0.7f, cx + s * 0.4f, cy + s, s * 0.1f)
    }
    private fun lureIcon(cx: Float, cy: Float, s: Float, a: Float) {
        sr.setColor(0.75f, 0.92f, 0.2f, a); sr.ellipse(cx - s * 0.3f, cy - s * 0.6f, s * 0.6f, s * 1.2f)
        sr.setColor(0.9f, 0.9f, 0.95f, a); sr.rectLine(cx, cy + s * 0.6f, cx, cy + s, s * 0.08f)
    }
    private fun fishIcon(cx: Float, cy: Float, s: Float, c: Color) {
        sr.color = c; sr.ellipse(cx - s, cy - s * 0.5f, s * 2f, s)
        sr.triangle(cx - s * 0.8f, cy, cx - s * 1.5f, cy + s * 0.5f, cx - s * 1.5f, cy - s * 0.5f)
        sr.setColor(1f, 1f, 1f, 1f); sr.circle(cx + s * 0.55f, cy + s * 0.1f, s * 0.1f)
    }
    private fun actIcon(fs: Int, cx: Float, cy: Float, s: Float) {
        sr.color = white
        when (fs) {
            0 -> rodIcon(cx, cy, s, 1f)
            1 -> for (k in -1..1) sr.circle(cx + k * s * 0.6f, cy, s * 0.17f)
            2 -> { sr.circle(cx, cy, s); sr.color = blue; sr.circle(cx, cy, s * 0.78f); sr.color = white
                sr.rectLine(cx, cy, cx, cy + s * 0.5f, s * 0.14f); sr.rectLine(cx, cy, cx + s * 0.35f, cy, s * 0.14f) }
            3, 5 -> { sr.circle(cx, cy, s); sr.color = blue; sr.circle(cx, cy, s * 0.62f); sr.color = white
                sr.triangle(cx + s * 0.55f, cy + s * 1.1f, cx + s * 1.35f, cy + s * 0.6f, cx + s * 0.55f, cy + s * 0.2f) }
            6 -> { sr.rect(cx - s * 0.6f, cy - s * 0.7f, s * 1.2f, s * 0.9f); for (k in -1..1) sr.rectLine(cx + k * s * 0.4f, cy + s * 0.2f, cx + k * s * 0.4f, cy + s * 0.9f, s * 0.28f) }
            else -> { sr.rectLine(cx - s, cy - s * 0.3f, cx + s * 0.3f, cy + s * 0.3f, s * 0.22f); sr.triangle(cx + s, cy + s * 0.5f, cx + s * 0.1f, cy + s * 0.7f, cx + s * 0.5f, cy - s * 0.2f) }
        }
    }

    fun draw(w: Float, h: Float, d: Float, fs: Int, money: Int, msg: String, msgT: Float, fD: Float,
             stickOn: Boolean, sx0: Float, sy0: Float, sx1: Float, sy1: Float) {
        sr.projectionMatrix.setToOrtho2D(0f, 0f, w, h); sb.projectionMatrix.setToOrtho2D(0f, 0f, w, h)
        font.data.setScale(d * 1.3f); font.color = white; gl.setText(font, msg)
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST); Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        sr.begin(ShapeRenderer.ShapeType.Filled)
        if (stickOn) {
            sr.setColor(1f, 1f, 1f, 0.18f); sr.circle(sx0, h - sy0, 60f * d); sr.setColor(1f, 1f, 1f, 0.4f)
            val dx = sx1 - sx0; val dy = sy0 - sy1; val l = hypot(dx, dy); val k = if (l > 60f * d) 60f * d / l else 1f
            sr.circle(sx0 + dx * k, h - sy0 + dy * k, 26f * d)
        }
        val a = actB(w, d); val j = jumpB(w, d); val b = bagB(w, d)
        sr.color = blue; sr.circle(a[0], a[1], a[2]); sr.color = grey; sr.circle(j[0], j[1], j[2])
        sr.color = if (fs == 4) Color(0.25f, 0.75f, 0.4f, 0.9f) else grey; sr.circle(b[0], b[1], b[2])
        actIcon(fs, a[0], a[1], a[2] * 0.5f)
        sr.color = white; val s = j[2] * 0.45f
        sr.triangle(j[0], j[1] + s, j[0] - s * 0.9f, j[1] - s * 0.6f, j[0] + s * 0.9f, j[1] - s * 0.6f)
        val bs = b[2] * 0.5f
        sr.rect(b[0] - bs * 0.7f, b[1] - bs * 0.7f, bs * 1.4f, bs * 1.2f)
        sr.rectLine(b[0] - bs * 0.35f, b[1] + bs * 0.5f, b[0] - bs * 0.35f, b[1] + bs * 0.95f, bs * 0.16f)
        sr.rectLine(b[0] + bs * 0.35f, b[1] + bs * 0.5f, b[0] + bs * 0.35f, b[1] + bs * 0.95f, bs * 0.16f)
        sr.rectLine(b[0] - bs * 0.35f, b[1] + bs * 0.95f, b[0] + bs * 0.35f, b[1] + bs * 0.95f, bs * 0.16f)
        // money box, heart, food
        sr.color = panelC; sr.rect(20f * d, 20f * d, 170f * d, 52f * d)
        sr.setColor(0.9f, 0.2f, 0.25f, 1f); sr.circle(40f * d, 118f * d, 12f * d); sr.circle(62f * d, 118f * d, 12f * d)
        sr.triangle(28f * d, 113f * d, 74f * d, 113f * d, 51f * d, 88f * d)
        sr.setColor(0.95f, 0.6f, 0.2f, 1f); sr.circle(130f * d, 106f * d, 20f * d)
        sr.color = white; sr.rectLine(123f * d, 94f * d, 123f * d, 118f * d, 3f * d); sr.rectLine(135f * d, 94f * d, 135f * d, 118f * d, 3f * d)
        // hotbar 1-7 + bait slot
        val hx = w / 2f - 200f * d
        for (k in 0..6) {
            val x = hx + k * 58f * d; val y = 14f * d
            if (k == 0) { sr.color = white; sr.rect(x - 3f * d, y - 3f * d, 58f * d, 58f * d) }
            sr.color = slotC; sr.rect(x, y, 52f * d, 52f * d)
            val cx = x + 26f * d; val cy = y + 26f * d; val is_ = 15f * d
            when (k) { 0 -> rodIcon(cx, cy, is_, 1f); 1 -> knifeIcon(cx, cy, is_, 0.35f); 2 -> pistolIcon(cx, cy, is_, 0.35f); 3 -> dynIcon(cx, cy, is_, 0.35f) }
        }
        sr.color = slotC; sr.rect(hx + 7 * 58f * d + 14f * d, 14f * d, 52f * d, 52f * d); lureIcon(hx + 7 * 58f * d + 40f * d, 40f * d, 15f * d, 1f)
        if (fs == 5) {   // fight meter: fish gets closer -> bar fills
            val bx = w * 0.3f; val bw = w * 0.4f; val by = h - 70f * d; val r = (1f - (fD - 2.2f) / 13.8f).coerceIn(0f, 1f)
            sr.color = panelC; sr.rect(bx - 6f * d, by - 6f * d, bw + 12f * d, 28f * d)
            sr.setColor(0.9f - 0.7f * r, 0.3f + 0.6f * r, 0.25f, 1f); sr.rect(bx, by, bw * r, 16f * d)
            fishIcon(bx + bw * r, by + 8f * d, 13f * d, white)
        }
        if (msgT > 0f && msg.isNotEmpty()) { sr.color = panelC; sr.rect(w / 2f - gl.width / 2f - 14f * d, 100f * d, gl.width + 28f * d, gl.height + 24f * d) }
        val p = panel(w, h, d)
        val cell = min((p[2] - 48f * d) / 6f, (p[3] - 190f * d) / 3f); val gx = p[0] + (p[2] - cell * 6f) / 2f; val gy = p[1] + p[3] - 80f * d - cell * 3f
        if (bagOpen) {
            sr.setColor(0f, 0f, 0f, 0.55f); sr.rect(0f, 0f, w, h); sr.color = panelC; sr.rect(p[0], p[1], p[2], p[3])
            for (k in 0 until 18) {
                val cx = gx + (k % 6) * cell; val cy = gy + (2 - k / 6) * cell
                sr.color = slotC; sr.rect(cx + 3f * d, cy + 3f * d, cell - 6f * d, cell - 6f * d)
                bag.getOrNull(k)?.let { fishIcon(cx + cell / 2f + 6f * d, cy + cell / 2f + 8f * d, cell * 0.27f, it.color) }
            }
            val xx = p[0] + p[2] - 34f * d; val xy = p[1] + p[3] - 34f * d
            sr.setColor(0.85f, 0.25f, 0.25f, 1f); sr.circle(xx, xy, 24f * d); sr.color = white
            sr.rectLine(xx - 9f * d, xy - 9f * d, xx + 9f * d, xy + 9f * d, 4f * d); sr.rectLine(xx - 9f * d, xy + 9f * d, xx + 9f * d, xy - 9f * d, 4f * d)
            sr.setColor(0.25f, 0.7f, 0.35f, 1f); sr.rect(p[0] + p[2] / 2f - 130f * d, p[1] + 14f * d, 260f * d, 52f * d)
            sr.setColor(1f, 0.85f, 0.2f, 1f); sr.circle(p[0] + p[2] / 2f - 100f * d, p[1] + 40f * d, 16f * d)
        }
        sr.end()
        sb.begin()
        font.draw(sb, "$" + money, 36f * d, 58f * d)
        font.data.setScale(d * 0.8f)
        for (k in 0..6) font.draw(sb, "${k + 1}", hx + k * 58f * d + 5f * d, 14f * d + 48f * d)
        font.data.setScale(d * 1.3f)
        if (msgT > 0f && msg.isNotEmpty()) font.draw(sb, msg, w / 2f - gl.width / 2f, 100f * d + 12f * d + gl.height)
        if (bagOpen) {
            font.draw(sb, "Backpack", p[0] + 24f * d, p[1] + p[3] - 22f * d)
            font.data.setScale(d * 0.9f)
            for (k in 0 until min(18, bag.size)) font.draw(sb, "$" + bag[k].value, gx + (k % 6) * cell + 10f * d, gy + (2 - k / 6) * cell + 28f * d)
            font.data.setScale(d * 1.3f)
            font.draw(sb, "$" + total(), p[0] + p[2] / 2f - 70f * d, p[1] + 52f * d)
        }
        sb.end()
    }
    fun dispose() { sr.dispose(); sb.dispose(); font.dispose() }
}
