package com.dazed.fishing3d

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.math.Vector3
import kotlin.math.*
import kotlin.random.Random

/** Underwater life: swaying seaweed, corals, seabed rocks and swimming fish. */
class Sea(private val models: MutableList<Model>, terr: (Float, Float) -> Float) {
    val inst = ArrayList<ModelInstance>()
    private class Weed(val i: ModelInstance, val x: Float, val y: Float, val z: Float, val h: Float, val ph: Float)
    private class Swim(val body: ModelInstance, val tail: ModelInstance, val r: Float, val y: Float, val sp: Float, val ph: Float)
    private class Cloud(val i: ModelInstance, val bx: Float, val y: Float, val z: Float, val s: Float)
    private val clouds = ArrayList<Cloud>()
    private val weeds = ArrayList<Weed>(); private val swimmers = ArrayList<Swim>()
    private fun m(c: Color) = ballModel(c).also { models.add(it) }

    init {
        val rnd = Random(11)
        val weedM = listOf(m(Color(0.08f, 0.55f, 0.28f, 1f)), m(Color(0.2f, 0.68f, 0.25f, 1f)))
        var n = 0; var tries = 0
        while (n < 55 && tries++ < 3000) {
            val a = rnd.nextFloat() * 6.283f; val r = 8f + rnd.nextFloat() * 30f
            val x = cos(a) * r; val z = sin(a) * r; val y = terr(x, z)
            if (y > -0.9f || y < -4.5f) continue
            for (k in 0 until 3) {
                val ox = x + rnd.nextFloat() * 0.6f - 0.3f; val oz = z + rnd.nextFloat() * 0.6f - 0.3f
                val i = ModelInstance(weedM[k % 2])
                weeds += Weed(i, ox, terr(ox, oz), oz, 0.8f + rnd.nextFloat() * 1.5f, rnd.nextFloat() * 6.28f); inst += i
            }
            n++
        }
        val coral = listOf(m(Color(0.95f, 0.4f, 0.5f, 1f)), m(Color(1f, 0.65f, 0.2f, 1f)), m(Color(0.7f, 0.4f, 0.9f, 1f)))
        n = 0; tries = 0
        while (n < 14 && tries++ < 3000) {
            val a = rnd.nextFloat() * 6.283f; val r = 10f + rnd.nextFloat() * 24f
            val x = cos(a) * r; val z = sin(a) * r; val y = terr(x, z)
            if (y > -1f || y < -3.5f) continue
            for (k in 0 until 4) { val s = 0.3f + rnd.nextFloat() * 0.5f
                inst += ModelInstance(coral[n % 3]).apply { transform.setToTranslation(x + rnd.nextFloat() * 0.8f - 0.4f, y + s * 0.4f, z + rnd.nextFloat() * 0.8f - 0.4f).scale(s, s * 1.3f, s) } }
            n++
        }
        val rockM = listOf(m(Color(0.33f, 0.36f, 0.4f, 1f)), m(Color(0.45f, 0.45f, 0.42f, 1f)))
        n = 0; tries = 0
        while (n < 28 && tries++ < 3000) {
            val a = rnd.nextFloat() * 6.283f; val r = 8f + rnd.nextFloat() * 32f
            val x = cos(a) * r; val z = sin(a) * r; val y = terr(x, z)
            if (y > -0.7f || y < -4.5f) continue
            val s = 0.5f + rnd.nextFloat() * 1.3f
            inst += ModelInstance(rockM[n % 2]).apply { transform.setToTranslation(x, y + s * 0.15f, z).rotate(Vector3.Y, rnd.nextFloat() * 360f).scale(s, s * 0.6f, s * 0.9f) }
            n++
        }
        val fm = listOf(m(Color(1f, 0.6f, 0.15f, 1f)), m(Color(0.3f, 0.7f, 1f, 1f)), m(Color(1f, 0.9f, 0.25f, 1f)))
        for (k in 0 until 14) {
            val s = Swim(ModelInstance(fm[k % 3]), ModelInstance(fm[k % 3]), 20f + rnd.nextFloat() * 14f, -1f - rnd.nextFloat() * 0.8f, 1.2f + rnd.nextFloat() * 0.8f, rnd.nextFloat() * 6.28f)
            swimmers += s; inst += s.body; inst += s.tail
        }
        val cm = m(Color.WHITE); cm.materials.first().set(ColorAttribute.createEmissive(0.85f, 0.88f, 0.95f, 1f))
        for (k in 0 until 7) {
            val bx = rnd.nextFloat() * 600f - 300f; val bz = rnd.nextFloat() * 500f - 250f; val by = 100f + rnd.nextFloat() * 30f
            for (p in 0 until 3) { val i = ModelInstance(cm); clouds += Cloud(i, bx + p * 14f - 14f, by + rnd.nextFloat() * 3f, bz + rnd.nextFloat() * 6f, 14f + rnd.nextFloat() * 10f); inst += i }
        }
    }

    fun update(t: Float) {
        for (c in clouds) c.i.transform.setToTranslation(((c.bx + t * 3f + 300f) % 600f) - 300f, c.y, c.z).scale(c.s * 1.6f, c.s * 0.5f, c.s)
        for (w in weeds) w.i.transform.setToTranslation(w.x, w.y, w.z)
            .rotate(Vector3.Z, sin(t * 1.3f + w.ph) * 14f).rotate(Vector3.X, cos(t * 1.1f + w.ph) * 11f)
            .translate(0f, w.h / 2f, 0f).scale(0.13f, w.h, 0.13f)
        for (s in swimmers) {
            val a = s.ph + t * s.sp / s.r; val deg = -a * 57.2958f
            val x = cos(a) * s.r; val z = sin(a) * s.r; val y = s.y + sin(t * 2f + s.ph) * 0.12f
            s.body.transform.setToTranslation(x, y, z).rotate(Vector3.Y, deg).scale(0.14f, 0.22f, 0.55f)
            s.tail.transform.setToTranslation(x, y, z).rotate(Vector3.Y, deg).translate(0f, 0f, -0.32f)
                .rotate(Vector3.Y, sin(t * 12f + s.ph) * 35f).translate(0f, 0f, -0.1f).scale(0.03f, 0.24f, 0.22f)
        }
    }
}
