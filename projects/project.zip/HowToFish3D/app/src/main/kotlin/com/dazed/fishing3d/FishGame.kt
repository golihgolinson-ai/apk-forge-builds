package com.dazed.fishing3d

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.*
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.*
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.IntAttribute
import com.badlogic.gdx.graphics.g3d.environment.DirectionalLight
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.graphics.glutils.ShaderProgram
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Vector3
import kotlin.math.*
import kotlin.random.Random

/** First-person island: walk, jump, swim. Left half = move stick, right half = look, bottom-right = jump. */
class FishGame : ApplicationAdapter() {
    private lateinit var cam: PerspectiveCamera
    private lateinit var mb: ModelBatch
    private lateinit var sb: SpriteBatch
    private lateinit var font: BitmapFont
    private lateinit var tint: Texture
    private lateinit var waterMesh: Mesh
    private lateinit var waterShader: ShaderProgram
    private val env = Environment()
    private val models = ArrayList<Model>()
    private val world = ArrayList<ModelInstance>()
    private lateinit var rig: Rig
    private lateinit var sr: ShapeRenderer
    private lateinit var sea: Sea
    private lateinit var hud: Hud
    private val shopPos = Vector3()
    private var bagTap = false; private var stickOn = false
    private var sx0 = 0f; private var sy0 = 0f; private var sx1 = 0f; private var sy1 = 0f
    private var heldVal = 0
    private lateinit var sunInst: ModelInstance
    private var fs = 0; private var ft = 0f; private var fwait = 0f; private var money = 0
    private var msg = "Aim at the water and tap CAST"; private var msgT = 8f; private var castTap = false

    private val pos = Vector3(0f, 3f, 0f)
    private var vy = 0f; private var yaw = 0f; private var pitch = 0f; private var time = 0f
    private var swim = false
    private val role = IntArray(5); private val ox = FloatArray(5); private val oy = FloatArray(5)
    private var mvF = 0f; private var mvS = 0f; private var jump = false
    private val sky = Color(0.6f, 0.82f, 1f, 1f)
    private val GRID = 160; private val SIZE = 200f

    // Island height. MUST match terrain() in the water fragment shader.
    private fun terr(x: Float, z: Float) =
        4f * exp(-(x * x + z * z) / 260f) - 1.2f + 0.25f * sin(x * 0.5f) * cos(z * 0.4f) - 0.05f * sqrt(x * x + z * z)

    // Walkable height: terrain plus the pier (x in -1.1..1.1, z in 11..24, deck at 0.5)
    private fun ground(x: Float, z: Float): Float {
        val g = terr(x, z)
        return if (abs(x) < 1.1f && z > 11f && z < 24f) max(g, 0.5f) else g
    }

    private fun box(w: Float, h: Float, d: Float, c: Color): Model =
        ModelBuilder().createBox(w, h, d, Material(ColorAttribute.createDiffuse(c)),
            (VertexAttributes.Usage.Position or VertexAttributes.Usage.Normal).toLong()).also { models += it }

    private fun groundColor(y: Float): Color {
        val sand = Color(0.93f, 0.85f, 0.62f, 1f); val grass = Color(0.3f, 0.66f, 0.25f, 1f)
        return when {
            y < -0.3f -> Color(0.74f, 0.7f, 0.5f, 1f).lerp(Color(0.35f, 0.45f, 0.55f, 1f), ((-y - 0.3f) / 3.5f).coerceIn(0f, 1f))
            y < 0.5f -> sand
            y < 1.2f -> sand.cpy().lerp(grass, (y - 0.5f) / 0.7f)
            y < 2.6f -> grass
            else -> Color(0.55f, 0.55f, 0.55f, 1f)
        }
    }

    private fun buildIsland() {
        val mbd = ModelBuilder(); mbd.begin()
        val part = mbd.part("t", GL20.GL_TRIANGLES,
            (VertexAttributes.Usage.Position or VertexAttributes.Usage.Normal or VertexAttributes.Usage.ColorPacked).toLong(),
            Material(IntAttribute.createCullFace(GL20.GL_NONE)))
        val n = 160; val half = 40f; val nor = Vector3()
        for (i in 0..n) for (j in 0..n) {
            val x = -half + i * 0.5f; val z = -half + j * 0.5f; val y = terr(x, z)
            nor.set(terr(x - .5f, z) - terr(x + .5f, z), 1f, terr(x, z - .5f) - terr(x, z + .5f)).nor()
            part.vertex(Vector3(x, y, z), nor, groundColor(y).apply { val f = 0.9f + 0.1f * sin(x * 2.1f) * cos(z * 1.7f); mul(f, f, f, 1f) }, null)
        }
        for (i in 0 until n) for (j in 0 until n) {
            val a = (i * (n + 1) + j).toShort(); val b = (a + 1).toShort()
            val c = (a + n + 1).toShort(); val d = (c + 1).toShort()
            part.index(a, b, c); part.index(b, d, c)
        }
        val m = mbd.end(); models += m; world += ModelInstance(m)

        val trunk = hexModel(0.32f, 3.2f, Color(0.42f, 0.22f, 0.28f, 1f)); models += trunk
        val ringM = hexModel(0.4f, 0.12f, Color(0.52f, 0.3f, 0.36f, 1f)); models += ringM
        val leaf = lowBallModel(Color(0.36f, 0.66f, 0.2f, 1f)); models += leaf
        val coco = ballModel(Color(0.35f, 0.22f, 0.1f, 1f)); models += coco
        val rockM = ballModel(Color(0.5f, 0.5f, 0.52f, 1f)); models += rockM
        val rnd = Random(7); var placed = 0
        while (placed < 14) {
            val x = rnd.nextFloat() * 28f - 14f; val z = rnd.nextFloat() * 28f - 14f; val y = terr(x, z)
            if (y < 0.9f || y > 2.4f) continue
            world += ModelInstance(trunk).apply { transform.setToTranslation(x, y + 1.6f, z) }
            for (r in 0 until 4) world += ModelInstance(ringM).apply { transform.setToTranslation(x, y + 0.5f + r * 0.8f, z) }
            for (k in 0 until 8) world += ModelInstance(leaf).apply {
                transform.setToTranslation(x, y + 3.2f, z).rotate(Vector3.Y, k * 45f).translate(1.5f, -0.1f, 0f).rotate(Vector3.Z, -22f).scale(3.2f, 0.12f, 0.8f)
            }
            for (k in 0 until 3) world += ModelInstance(coco).apply { transform.setToTranslation(x + 0.25f * (k - 1), y + 3.0f, z + 0.15f).scale(0.28f, 0.28f, 0.28f) }
            placed++
        }
        var rocks = 0
        while (rocks < 12) {
            val x = rnd.nextFloat() * 40f - 20f; val z = rnd.nextFloat() * 40f - 20f; val y = terr(x, z)
            if (y < -0.4f || y > 0.6f) continue
            world += ModelInstance(rockM).apply { transform.setToTranslation(x, y, z).rotate(Vector3.Y, rnd.nextFloat() * 360f).scale(0.6f + rnd.nextFloat() * 1.2f, 0.5f + rnd.nextFloat() * 0.6f, 0.6f + rnd.nextFloat()) }
            rocks++
        }
        val blade = hexModel(0.06f, 1f, Color(0.35f, 0.65f, 0.22f, 1f)); models += blade
        var gc = 0; var gt = 0
        while (gc < 120 && gt++ < 4000) {
            val x = rnd.nextFloat() * 30f - 15f; val z = rnd.nextFloat() * 30f - 15f; val y = terr(x, z)
            if (y < 0.55f || y > 2.2f || (abs(x) < 1.5f && z > 9f)) continue
            val h = 0.4f + rnd.nextFloat() * 0.6f
            world += ModelInstance(blade).apply { transform.setToTranslation(x, y + h / 2f, z).rotate(Vector3.Z, rnd.nextFloat() * 30f - 15f).rotate(Vector3.X, rnd.nextFloat() * 30f - 15f).scale(1f, h, 1f) }
            gc++
        }
        val wood = box(1f, 1f, 1f, Color(0.55f, 0.38f, 0.2f, 1f))
        for (k in 0 until 12) world += ModelInstance(wood).apply { transform.setToTranslation(0f, 0.45f, 12f + k + 0.5f).scale(2.2f, 0.1f, 0.85f) }
        val post = hexModel(0.22f, 1f, Color(0.35f, 0.22f, 0.1f, 1f)); models += post
        for (k in 0 until 5) for (sx in intArrayOf(-1, 1)) world += ModelInstance(post).apply { transform.setToTranslation(sx * 1.05f, 0f, 12.5f + k * 2.5f).scale(1f, 2.6f, 1f) }
        // Beach shop (west side) with a seller behind the counter
        val hx = -10.5f; val hz = -2f; val hy = terr(hx, hz); val fy = terr(hx + 3.6f, hz); shopPos.set(hx + 3.2f, fy, hz)
        val cream = box(1f, 1f, 1f, Color(0.92f, 0.88f, 0.78f, 1f)); val roofM = box(1f, 1f, 1f, Color(0.8f, 0.72f, 0.6f, 1f))
        val darkM = box(1f, 1f, 1f, Color(0.3f, 0.2f, 0.18f, 1f)); val counter = box(1f, 1f, 1f, Color(0.5f, 0.27f, 0.22f, 1f))
        val hexRed = hexModel(1f, 1f, Color(0.85f, 0.15f, 0.18f, 1f)); models += hexRed
        val skin2 = ballModel(Color(0.72f, 0.5f, 0.36f, 1f)); models += skin2
        val hair = ballModel(Color(0.95f, 0.8f, 0.2f, 1f)); models += hair
        fun at(m: Model, x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, rz: Float = 0f) {
            world += ModelInstance(m).apply { transform.setToTranslation(hx + x, y, hz + z).rotate(Vector3.Z, rz).scale(sx, sy, sz) }
        }
        at(cream, 0f, hy + 0.6f, 0f, 5f, 3.6f, 4f)
        at(roofM, -1.15f, hy + 2.95f, 0f, 3.2f, 0.2f, 4.8f, 25f); at(roofM, 1.15f, hy + 2.95f, 0f, 3.2f, 0.2f, 4.8f, -25f)
        at(darkM, 2.52f, hy + 1.4f, 0f, 0.1f, 1.1f, 2.4f)
        at(counter, 4.1f, fy + 0.95f, 0f, 0.8f, 0.12f, 2.8f); at(counter, 4.1f, fy + 0.45f, 0f, 0.7f, 0.9f, 2.6f)
        at(hexRed, 3.2f, fy + 1.0f, 0f, 0.5f, 0.7f, 0.36f); at(skin2, 3.2f, fy + 1.62f, 0f, 0.42f, 0.5f, 0.42f)
        at(hair, 3.12f, fy + 1.66f, 0f, 0.5f, 0.55f, 0.5f); at(hexRed, 3.2f, fy + 1.92f, 0f, 0.44f, 0.12f, 0.44f)
    }

    private fun buildWater() {
        val v = FloatArray((GRID + 1) * (GRID + 1) * 2); var k = 0
        for (i in 0..GRID) for (j in 0..GRID) { v[k++] = -SIZE / 2 + i * SIZE / GRID; v[k++] = -SIZE / 2 + j * SIZE / GRID }
        val idx = ShortArray(GRID * GRID * 6); k = 0
        for (i in 0 until GRID) for (j in 0 until GRID) {
            val a = i * (GRID + 1) + j; val b = a + 1; val c = a + GRID + 1; val d = c + 1
            idx[k++] = a.toShort(); idx[k++] = b.toShort(); idx[k++] = c.toShort()
            idx[k++] = b.toShort(); idx[k++] = d.toShort(); idx[k++] = c.toShort()
        }
        waterMesh = Mesh(true, v.size / 2, idx.size, VertexAttribute(VertexAttributes.Usage.Position, 2, "a_pos"))
        waterMesh.setVertices(v); waterMesh.setIndices(idx)
        ShaderProgram.pedantic = false
        waterShader = ShaderProgram(WATER_VS, WATER_FS)
        if (!waterShader.isCompiled) Gdx.app.error("water", waterShader.log)
    }

    override fun create() {
        cam = PerspectiveCamera(70f, Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat()).apply { near = 0.05f; far = 400f }
        env.set(ColorAttribute(ColorAttribute.AmbientLight, 0.55f, 0.57f, 0.62f, 1f))
        env.add(DirectionalLight().set(1f, 0.97f, 0.9f, -0.5f, -0.8f, -0.6f))
        env.add(DirectionalLight().set(0.3f, 0.38f, 0.55f, 0.6f, -0.3f, 0.5f))
        mb = ModelBatch(); sb = SpriteBatch()
        font = BitmapFont().apply { data.setScale(Gdx.graphics.density * 1.4f) }
        tint = Texture(Pixmap(1, 1, Pixmap.Format.RGBA8888).apply { setColor(Color.WHITE); fill() })
        buildIsland(); buildWater()
        rig = Rig(models)
        sea = Sea(models) { x, z -> terr(x, z) }
        hud = Hud()
        sr = ShapeRenderer()
        val sunM = ballModel(Color(1f, 0.95f, 0.7f, 1f)); sunM.materials.first().set(ColorAttribute.createEmissive(1f, 0.95f, 0.7f, 1f))
        models += sunM; sunInst = ModelInstance(sunM)
    }

    private fun readInput() {
        val w = Gdx.graphics.width; val h = Gdx.graphics.height; val d = Gdx.graphics.density
        mvF = 0f; mvS = 0f; jump = false; castTap = false; bagTap = false; stickOn = false
        for (i in 0..4) {
            if (!Gdx.input.isTouched(i)) { role[i] = 0; continue }
            val x = Gdx.input.getX(i).toFloat(); val y = Gdx.input.getY(i).toFloat()
            if (role[i] == 0) { val rb = hud.hit(w.toFloat(), h.toFloat(), d, x, y); role[i] = if (rb != 0) rb else if (x < w / 2f) 1 else 2; if (role[i] == 4) castTap = true; if (role[i] == 5) bagTap = true; ox[i] = x; oy[i] = y }
            when (role[i]) {
                1 -> { stickOn = true; sx0 = ox[i]; sy0 = oy[i]; sx1 = x; sy1 = y; mvS = ((x - ox[i]) / (70f * d)).coerceIn(-1f, 1f); mvF = (-(y - oy[i]) / (70f * d)).coerceIn(-1f, 1f) }
                2 -> { yaw -= (x - ox[i]) * 0.15f; pitch = (pitch - (y - oy[i]) * 0.15f).coerceIn(-89f, 89f); ox[i] = x; oy[i] = y }
                3 -> jump = true
            }
        }
    }

    private fun physics(dt: Float) {
        val yr = yaw * MathUtils.degreesToRadians; val pr = pitch * MathUtils.degreesToRadians
        val fx = -sin(yr); val fz = -cos(yr); val rx = cos(yr); val rz = -sin(yr)
        swim = ground(pos.x, pos.z) < -1.2f
        val sp = if (swim) 3.2f else 5.5f
        val len = max(1f, sqrt(mvF * mvF + mvS * mvS))
        val k = if (swim) cos(pr) else 1f
        pos.x += ((fx * mvF * k + rx * mvS) / len) * sp * dt
        pos.z += ((fz * mvF * k + rz * mvS) / len) * sp * dt
        val floor = ground(pos.x, pos.z)
        if (swim) {
            var t = sin(pr) * mvF * sp
            if (mvF * mvF + mvS * mvS < 0.01f) t = 1f
            if (jump) t += 3f
            vy += (t - vy) * min(1f, 4f * dt); pos.y += vy * dt
            val cap = -1.35f + 0.05f * sin(time * 1.6f)
            if (pos.y > cap) { pos.y = cap; if (vy > 0) vy = 0f }
        } else {
            vy -= 22f * dt
            if (jump && pos.y <= floor + 0.02f) vy = 7.5f
            pos.y += vy * dt
        }
        if (pos.y < floor) { pos.y = floor; if (vy < 0) vy = 0f }
    }

    private fun placeView(base: Matrix4, i: ModelInstance, x: Float, y: Float, z: Float, rx: Float) {
        i.transform.set(base).translate(x, y, z).rotate(Vector3.X, rx)
    }

    private fun bagLogic() {
        if (!bagTap) return
        if (fs == 4) {   // holding a fish -> put it into the backpack
            hud.bag += Hud.Item(heldVal, Color().fromHsv((heldVal * 37f) % 360f, 0.45f, 0.85f).also { it.a = 1f })
            rig.fishMode = 0; fs = 0; say("Stored in backpack")
        } else hud.bagOpen = true
    }

    private fun panelTap() {
        val w = Gdx.graphics.width.toFloat(); val h = Gdx.graphics.height.toFloat()
        when (hud.panelHit(w, h, Gdx.graphics.density, Gdx.input.x.toFloat(), Gdx.input.y.toFloat())) {
            1 -> hud.bagOpen = false
            2 -> { val tot = hud.total()
                if (tot == 0) say("Backpack is empty")
                else if (hypot(pos.x - shopPos.x, pos.z - shopPos.z) < 6f) { money += tot; hud.bag.clear(); say("Sold for $$tot") }
                else say("Sell at the beach shop (west)") }
        }
    }

    private fun say(t: String) { msg = t; msgT = 3f }

    private var fD = 0f; private var fAng = 0f; private var fPull = 1f; private var fVal = 0; private var bendS = 0f

    private fun fishing(dt: Float) {
        ft += dt; if (msgT > 0f) msgT -= dt
        val dir = Vector3(cam.direction); if (dir.y < 0.15f) { dir.y = 0.15f; dir.nor() }
        var bendT = 0f
        when (fs) {
            0 -> if (castTap) { rig.throwBobber(dir); fs = 1; say("Cast!") }
            1 -> when (rig.landed) {
                1 -> { fs = 2; ft = 0f; fwait = 2f + Random.nextFloat() * 4f; rig.landed = 0; say("Waiting for a bite...") }
                2 -> { rig.recall(); fs = 0; say("It fell on land") }
            }
            2 -> if (castTap) { rig.recall(); fs = 0; say("Too early!") } else if (ft > fwait) { fs = 3; ft = 0f; say("BITE! Tap REEL!") }
            3 -> {
                rig.dip = 0.25f * abs(sin(time * 25f)) + 0.1f
                if (castTap) {
                    val dx = rig.bobber.x - pos.x; val dz = rig.bobber.z - pos.z
                    fD = hypot(dx, dz); fAng = atan2(-dx, -dz); fPull = 0.9f + Random.nextFloat() * 1.3f
                    fVal = (10 + fPull * 22f).toInt(); fs = 5; say("It's heavy! Tap REEL fast!")
                } else if (ft > 1.3f) { rig.recall(); fs = 0; say("It got away") }
            }
            5 -> {
                val burst = fPull * (1f + 0.9f * max(0f, sin(time * 1.7f)))
                fD += burst * dt; if (castTap) { fD -= 0.75f; rig.spin += 1.5f }
                fAng += sin(time * 0.9f) * 0.5f * dt
                rig.setFloat(pos.x - sin(fAng) * fD, pos.z - cos(fAng) * fD)
                rig.dip = 0.1f + 0.08f * abs(sin(time * 28f))
                bendT = (burst / 2.6f).coerceIn(0f, 1f)
                if (fD < 2.2f) { rig.hookFish(); fs = 6; say("Got it! Tap GRAB") }
                else if (fD > 16f) { rig.recall(); fs = 0; say("Line snapped!") }
            }
            6 -> { bendT = 0.3f; if (castTap) { heldVal = fVal; rig.takeFish(); fs = 4; say("Caught a fish worth $$fVal!") } }
            4 -> if (castTap) { rig.throwFish(dir); fs = 0; say("Splash!") }
        }
        bendS += (bendT - bendS) * min(1f, dt * 6f); rig.bend = bendS
    }

    override fun render() {
        val dt = min(Gdx.graphics.deltaTime, 0.05f); time += dt
        if (hud.bagOpen) {
            mvF = 0f; mvS = 0f; jump = false; castTap = false; bagTap = false; stickOn = false
            if (Gdx.input.justTouched()) panelTap()
        } else readInput()
        bagLogic()
        physics(dt); fishing(dt)
        val yr = yaw * MathUtils.degreesToRadians; val pr = pitch * MathUtils.degreesToRadians
        val eye = Vector3(pos.x, pos.y + 1.6f, pos.z)
        cam.position.set(eye)
        cam.direction.set(-sin(yr) * cos(pr), sin(pr), -cos(yr) * cos(pr)); cam.up.set(0f, 1f, 0f); cam.update()

        Gdx.gl.glClearColor(sky.r, sky.g, sky.b, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)
        val sw = Gdx.graphics.width.toFloat(); val sh = Gdx.graphics.height.toFloat()
        val hz = sh * (0.5f - tan(pitch * MathUtils.degreesToRadians) / tan(35f * MathUtils.degreesToRadians) * 0.5f)
        val y0 = hz.coerceAtLeast(0f)
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        if (sh - y0 > 0f) { sr.begin(ShapeRenderer.ShapeType.Filled)
            sr.rect(0f, y0, sw, sh - y0, sky, sky, Color(0.25f, 0.55f, 0.95f, 1f), Color(0.25f, 0.55f, 0.95f, 1f)); sr.end() }
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
        sunInst.transform.setToTranslation(eye.x + 147f, eye.y + 236f, eye.z + 177f).scale(30f, 30f, 30f)
        mb.begin(cam); sea.update(time); mb.render(sunInst, env); mb.render(world, env); mb.render(sea.inst, env); mb.end()

        val step = SIZE / GRID
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST); Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        waterShader.bind()
        waterShader.setUniformMatrix("u_proj", cam.combined)
        waterShader.setUniformf("u_off", floor(eye.x / step) * step, floor(eye.z / step) * step)
        waterShader.setUniformf("u_time", time)
        waterShader.setUniformf("u_cam", eye.x, eye.y, eye.z)
        waterMesh.render(waterShader, GL20.GL_TRIANGLES)

        // First-person rig (drawn on top)
        Gdx.gl.glClear(GL20.GL_DEPTH_BUFFER_BIT)
        val fwd = Vector3(cam.direction); val rgt = Vector3(fwd).crs(Vector3.Y).nor(); val upv = Vector3(rgt).crs(fwd).nor()
        rig.update(dt, eye, fwd, rgt, upv, yaw, min(1f, abs(mvF) + abs(mvS)), swim, time) { x, z -> ground(x, z) }
        mb.begin(cam); mb.render(rig.out, env); mb.end()

        sb.begin()
        if (eye.y < 0.02f) { sb.setColor(0f, 0.3f, 0.6f, 0.4f); sb.draw(tint, 0f, 0f, Gdx.graphics.width.toFloat(), Gdx.graphics.height.toFloat()); sb.setColor(Color.WHITE) }
        sb.end()
        hud.draw(sw, sh, Gdx.graphics.density, fs, money, if (msgT > 0f) msg else "", msgT, fD, stickOn, sx0, sy0, sx1, sy1)
        Gdx.gl.glDisable(GL20.GL_BLEND)
    }

    override fun dispose() { hud.dispose(); sr.dispose(); mb.dispose(); sb.dispose(); font.dispose(); tint.dispose(); waterMesh.dispose(); waterShader.dispose(); models.forEach { it.dispose() } }

    companion object {
        const val WATER_VS = """
precision highp float;
attribute vec2 a_pos;
uniform mat4 u_proj; uniform vec2 u_off; uniform float u_time;
varying vec3 v_pos; varying vec3 v_nrm;
void wave(vec2 p, vec2 d, float k, float a, float sp, inout float h, inout vec2 g) {
  float ph = dot(p, d) * k + u_time * sp;
  h += a * sin(ph); g += a * k * cos(ph) * d;
}
void main() {
  vec2 p = a_pos + u_off; float h = 0.0; vec2 g = vec2(0.0);
  wave(p, normalize(vec2(1.0, 0.3)), 0.35, 0.12, 1.1, h, g);
  wave(p, normalize(vec2(-0.4, 1.0)), 0.6, 0.07, 1.6, h, g);
  wave(p, normalize(vec2(0.7, -0.8)), 1.1, 0.035, 2.4, h, g);
  v_pos = vec3(p.x, h, p.y); v_nrm = normalize(vec3(-g.x, 1.0, -g.y));
  gl_Position = u_proj * vec4(v_pos, 1.0);
}"""
        const val WATER_FS = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform vec3 u_cam; uniform float u_time;
varying vec3 v_pos; varying vec3 v_nrm;
float terrain(vec2 p) {
  return 4.0 * exp(-dot(p, p) / 260.0) - 1.2 + 0.25 * sin(p.x * 0.5) * cos(p.y * 0.4) - 0.05 * length(p);
}
void main() {
  vec2 q = v_pos.xz;
  vec3 N = normalize(v_nrm);
  N = normalize(N + 0.06 * vec3(sin(q.x * 3.0 + u_time * 2.0) + sin(q.y * 2.3 - u_time * 1.7), 0.0,
                                cos(q.y * 3.1 + u_time * 1.9) + cos(q.x * 2.1 - u_time * 1.3)));
  vec3 V = normalize(u_cam - v_pos);
  float fres = pow(1.0 - max(dot(N, V), 0.0), 3.0);
  float depth = max(-terrain(q), 0.0);
  vec3 sky = vec3(0.6, 0.82, 1.0);
  vec3 col = mix(vec3(0.1, 0.62, 0.85), vec3(0.0, 0.1, 0.42), smoothstep(0.0, 6.0, depth));
  col = mix(col, sky, fres * 0.7);
  col += 0.06 * (1.0 - smoothstep(0.0, 3.0, depth)) * (sin(q.x * 6.0 + u_time * 1.5) * sin(q.y * 6.0 - u_time * 1.2));
  vec3 L = normalize(vec3(0.5, 0.8, 0.6));
  col += vec3(1.0, 0.95, 0.8) * pow(max(dot(reflect(-L, N), V), 0.0), 120.0) * 1.2;
  col *= 0.94 + 0.12 * fract(sin(dot(floor(q * 0.8), vec2(12.9898, 78.233))) * 43758.5453);
  float edge = smoothstep(0.6, 0.0, depth);
  float foam = clamp(edge * (0.55 + 0.45 * sin(depth * 25.0 - u_time * 3.0 + sin(q.x * 2.0) * 2.0)) + smoothstep(0.15, 0.0, depth), 0.0, 1.0);
  col = mix(col, vec3(1.0), foam * 0.85);
  float alpha = max(max(clamp(0.18 + depth * 0.2, 0.0, 0.93), fres * 0.8), foam);
  float fog = smoothstep(60.0, 180.0, length(u_cam - v_pos));
  gl_FragColor = vec4(mix(col, sky, fog), mix(alpha, 1.0, fog));
}"""
    }
}
