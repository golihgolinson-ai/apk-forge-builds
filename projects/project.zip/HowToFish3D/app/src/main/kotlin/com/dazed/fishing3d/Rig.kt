package com.dazed.fishing3d

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.VertexAttributes
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.Matrix4
import com.badlogic.gdx.math.Quaternion
import com.badlogic.gdx.math.Vector3
import kotlin.math.*
import kotlin.random.Random

private val USAGE = (VertexAttributes.Usage.Position or VertexAttributes.Usage.Normal).toLong()
private fun mat(c: Color) = Material(ColorAttribute.createDiffuse(c))
/** Unit sphere (diameter 1), scale it per instance. */
fun ballModel(c: Color): Model = ModelBuilder().createSphere(1f, 1f, 1f, 14, 14, mat(c), USAGE)
/** Cylinder along Y, diameter [d], height [h]. */
/** Hexagonal prism (6 sides) along Y, diameter [d], height [h]. */
fun hexModel(d: Float, h: Float, c: Color): Model = ModelBuilder().createCylinder(d, h, d, 6, mat(c), USAGE)
/** Low-poly faceted ball (leaves, rocks). */
fun lowBallModel(c: Color): Model = ModelBuilder().createSphere(1f, 1f, 1f, 6, 4, mat(c), USAGE)
fun cylModel(d: Float, h: Float, c: Color): Model = ModelBuilder().createCylinder(d, h, d, 12, mat(c), USAGE)

/**
 * First-person body: chunky cartoon hands that are spring-driven bodies (they lag, swing and drag in water),
 * two-bone IK arms with elbows, a verlet-simulated fishing rod, and a dangling line with a bobber.
 */
class Rig(private val models: MutableList<Model>) {
    private class Pool(val m: Model) {
        val l = ArrayList<ModelInstance>(); var n = 0
        fun next(): ModelInstance { if (n == l.size) l += ModelInstance(m); return l[n++] }
    }
    private fun mk(m: Model): Pool { models += m; return Pool(m) }

    val out = ArrayList<ModelInstance>()
    private val skinB = mk(ballModel(Color(0.87f, 0.72f, 0.52f, 1f)))
    private val sleeveB = mk(ballModel(Color(0.95f, 0.5f, 0.1f, 1f)))
    private val redB = mk(ballModel(Color(0.75f, 0.92f, 0.2f, 1f)))
    private val sleeveC = mk(hexModel(1f, 1f, Color(0.24f, 0.27f, 0.45f, 1f)))
    private val skinC = mk(hexModel(1f, 1f, Color(0.87f, 0.72f, 0.52f, 1f)))
    private val woodC = mk(hexModel(1f, 1f, Color(0.4f, 0.25f, 0.1f, 1f)))
    private val lineC = mk(cylModel(1f, 1f, Color.WHITE))
    private val fishB = mk(ballModel(Color(0.4f, 0.62f, 0.55f, 1f)))
    private val hexS = mk(hexModel(1f, 1f, Color(0.95f, 0.5f, 0.1f, 1f)))
    private val hexSk = mk(hexModel(1f, 1f, Color(0.87f, 0.72f, 0.52f, 1f)))
    private val hexP = mk(hexModel(1f, 1f, Color(0.95f, 0.5f, 0.1f, 1f)))
    private val hexN = mk(hexModel(1f, 1f, Color(0.24f, 0.27f, 0.45f, 1f)))
    private val hexB = mk(hexModel(1f, 1f, Color(0.1f, 0.08f, 0.1f, 1f)))
    private val rodB = mk(hexModel(1f, 1f, Color(0.08f, 0.08f, 0.13f, 1f)))
    private val blueB = mk(hexModel(1f, 1f, Color(0.35f, 0.62f, 0.92f, 1f)))
    private val reelB = mk(hexModel(1f, 1f, Color(0.2f, 0.22f, 0.32f, 1f)))
    private val silverB = mk(hexModel(1f, 1f, Color(0.82f, 0.84f, 0.88f, 1f)))
    private val bellyB = mk(ballModel(Color(0.93f, 0.96f, 0.95f, 1f)))
    private val pools = listOf(skinB, sleeveB, redB, sleeveC, skinC, woodC, lineC, fishB, hexS, hexSk, hexP, hexN, hexB, rodB, blueB, reelB, silverB, bellyB)
    var spin = 0f   // reel crank angle (FishGame adds to it on every REEL tap)
    private val reelP = Vector3(); private val knobP = Vector3(); private val rotR = Quaternion()
    private val rz90 = Quaternion(Vector3.Z, 90f)
    var bend = 0f                 // rod bend 0..1 (toward the bobber / fish)
    private var hookAmp = 1f
    private val bendV = Vector3(); private val hookP = Vector3(); private val rotX = Quaternion()
    private val rx90 = Quaternion(Vector3.X, 90f)
    val bobber: Vector3 get() = bp
    fun setFloat(x: Float, z: Float) { bp.x = x; bp.z = z }
    fun hookFish() { mode = 3; bp.set(rp[7]).y -= 0.6f; bq.set(bp); hookAmp = 1f }
    fun takeFish() { recall(); holdFish() }
    var mode = 0        // bobber: 0 dangling on the rod, 1 flying, 2 floating on the water
    var landed = 0      // set when the bobber lands: 1 = water, 2 = land (FishGame resets it)
    var dip = 0f        // bobber dips when a fish bites
    var fishMode = 0    // 0 none, 1 held in the right hand, 2 thrown (physics)
    var fishAmp = 1f    // how hard the fish thrashes
    private val bv = Vector3(); private val fp = Vector3(); private val fv = Vector3(); private val fh = Vector3(0f, 0f, 1f)
    private var fishT = 0f
    private val fx = Vector3(); private val fy = Vector3(); private val basis2 = Matrix4(); private val rotF = Quaternion()
    fun throwBobber(dir: Vector3) { mode = 1; landed = 0; bp.set(rp[7]); bv.set(dir).scl(13f); bv.y += 2.5f }
    fun recall() { mode = 0; landed = 0; dip = 0f; bp.set(rp[7]).y -= 0.9f; bq.set(bp) }
    fun holdFish() { fishMode = 1; fishAmp = 1f; fp.set(hp[0]); fv.setZero() }
    fun throwFish(dir: Vector3) { fishMode = 2; fishT = 0f; fv.set(dir).scl(7f); fv.y += 3f; fh.set(dir.x, 0f, dir.z).nor() }

    private val hp = arrayOf(Vector3(), Vector3()); private val hv = arrayOf(Vector3(), Vector3())
    private val rp = Array(8) { Vector3() }; private val rq = Array(8) { Vector3() }
    private val bp = Vector3(); private val bq = Vector3()
    private var init = false
    private val t = Vector3(); private val a = Vector3(); private val d = Vector3(); private val dn = Vector3()
    private val pole = Vector3(); private val el = Vector3(); private val sh = Vector3(); private val wr = Vector3()
    private val dirT = Vector3(); private val tmp = Vector3(); private val sc = Vector3()
    private val q = Quaternion(); private val rot = Quaternion(); private val basis = Matrix4()
    private val back = Vector3()

    private fun seg(p: Pool, from: Vector3, to: Vector3, r: Float) {
        d.set(to).sub(from); val len = d.len(); if (len < 1e-4f) return
        tmp.set(from).add(to).scl(0.5f); q.setFromCross(Vector3.Y, d.scl(1f / len))
        p.next().transform.set(tmp, q, sc.set(r * 2f, len, r * 2f))
    }
    private fun ball(p: Pool, c: Vector3, sx: Float, sy: Float, sz: Float, r: Quaternion) {
        p.next().transform.set(c, r, sc.set(sx, sy, sz))
    }

    private fun drawFish(p: Vector3, f: Vector3, upv: Vector3, time: Float, amp: Float) {
        fx.set(upv).crs(f).nor(); fy.set(f).crs(fx).nor()
        basis2.set(fx, fy, f, Vector3.Zero); basis2.getRotation(rotF)
        ball(fishB, p, 0.16f, 0.24f, 0.55f, rotF)
        tmp.set(p).mulAdd(fy, -0.07f); ball(bellyB, tmp, 0.15f, 0.12f, 0.5f, rotF)
        val sw = sin(time * 18f) * 0.14f * amp
        tmp.set(p).mulAdd(f, -0.33f).mulAdd(fx, sw); ball(fishB, tmp, 0.05f, 0.18f, 0.22f, rotF)
        tmp.mulAdd(f, -0.15f).mulAdd(fx, sw * 1.6f); ball(fishB, tmp, 0.02f, 0.26f, 0.2f, rotF)
        tmp.set(p).mulAdd(fy, 0.12f); ball(fishB, tmp, 0.02f, 0.12f, 0.25f, rotF)
    }

    fun update(dt: Float, eye: Vector3, fwd: Vector3, rgt: Vector3, up: Vector3, yaw: Float,
               moving: Float, swim: Boolean, time: Float, ground: (Float, Float) -> Float) {
        for (p in pools) p.n = 0
        out.clear()
        back.set(fwd).scl(-1f); basis.set(rgt, up, back, Vector3.Zero); basis.getRotation(rot); rotX.set(rot).mul(rx90)

        for (side in 0..1) {
            val sd = if (side == 0) 1f else -1f
            val s = moving * sin(time * (if (swim) 4.5f else 8f) + side * PI.toFloat())
            t.set(eye).mulAdd(fwd, 0.6f + (if (swim) 0.26f else 0.04f) * s).mulAdd(rgt, 0.3f * sd)
                .mulAdd(up, -0.32f + (if (swim) -0.1f else 0.03f) * s)
            if (side == 1 && init) t.set(knobP).mulAdd(fwd, 0.02f)   // left hand rests on the reel crank
            if (!init) { hp[side].set(t); hv[side].setZero() }
            val h = dt / 2f
            repeat(2) {
                val drag = 12f + if (hp[side].y < 0f) 18f else 0f
                a.set(t).sub(hp[side]).scl(95f).mulAdd(hv[side], -drag)
                hv[side].mulAdd(a, h); hp[side].mulAdd(hv[side], h)
                val g = ground(hp[side].x, hp[side].z) + 0.07f
                if (hp[side].y < g) { hp[side].y = g; if (hv[side].y < 0f) hv[side].y = 0f }
            }
            if (hp[side].dst2(t) > 0.64f) hp[side].lerp(t, 0.5f)

            // IK arm: shoulder -> elbow -> hand
            sh.set(eye).mulAdd(rgt, 0.26f * sd).mulAdd(up, -0.5f).mulAdd(fwd, -0.05f)
            d.set(hp[side]).sub(sh); val dist = d.len()
            if (dist > 1e-3f) {
                dn.set(d).scl(1f / dist)
                val cd = dist.coerceIn(0.1f, 0.82f); val ha = cd / 2f
                val hg = sqrt(max(0.42f * 0.42f - ha * ha, 0.001f))
                pole.set(up).scl(-1f).mulAdd(rgt, 0.7f * sd).mulAdd(fwd, -0.3f)
                pole.mulAdd(dn, -pole.dot(dn)).nor()
                el.set(sh).mulAdd(dn, ha).mulAdd(pole, hg)
                seg(sleeveC, sh, el, 0.058f)
                ball(hexN, el, 0.125f, 0.125f, 0.125f, rot)
                wr.set(el).lerp(hp[side], 0.92f)
                seg(sleeveC, el, wr, 0.05f); seg(skinC, wr, hp[side], 0.04f)
            }
            // blocky hexagonal hand: palm + 3 fingers + thumb (4 digits)
            ball(hexSk, hp[side], 0.17f, 0.09f, 0.17f, rot)
            for (k in 0..2) {
                tmp.set(hp[side]).mulAdd(rgt, -0.045f + 0.045f * k).mulAdd(fwd, 0.11f)
                ball(hexSk, tmp, 0.052f, 0.14f, 0.052f, rotX)
            }
            tmp.set(hp[side]).mulAdd(rgt, -0.085f * sd).mulAdd(fwd, 0.05f).mulAdd(up, 0.02f)
            ball(hexSk, tmp, 0.06f, 0.11f, 0.06f, rotX)
        }

        // Verlet fishing rod held by the right hand
        dirT.set(fwd).scl(0.82f).mulAdd(up, 0.57f).nor()
        rp[0].set(hp[0]).mulAdd(dirT, -0.35f)
        if (!init) for (i in 0..7) { rp[i].set(rp[0]).mulAdd(dirT, 0.28f * i); rq[i].set(rp[i]) }
        bendV.set(bp).sub(rp[7]); val bl = bendV.len(); if (bl > 1e-3f) bendV.scl(1f / bl) else bendV.setZero()
        for (i in 1..7) {
            t.set(rp[0]).mulAdd(dirT, 0.28f * i).mulAdd(bendV, bend * 0.9f * (i / 7f) * (i / 7f))
            a.set(rp[i]).sub(rq[i]).scl(0.97f); rq[i].set(rp[i]); rp[i].add(a); rp[i].y -= 4f * dt * dt
            rp[i].lerp(t, min(1f, dt * 14f * (1f - i / 10f)))
        }
        repeat(2) { for (i in 1..7) { d.set(rp[i]).sub(rp[i - 1]); val l = d.len(); if (l > 1e-4f) rp[i].set(rp[i - 1]).mulAdd(d, 0.28f / l) } }
        for (i in 1..7) seg(if (i <= 2) rodB else blueB, rp[i - 1], rp[i], if (i <= 2) 0.034f else 0.018f - 0.012f * (i - 3) / 4f)
        // Spinning reel under the handle + crank (left hand holds the crank), blue ring, guide rings
        reelP.set(rp[0]).mulAdd(dirT, 0.14f).mulAdd(up, -0.1f)
        rotR.set(rot).mul(rz90)
        ball(reelB, reelP, 0.14f, 0.09f, 0.14f, rotR); ball(silverB, reelP, 0.1f, 0.11f, 0.1f, rotR)
        knobP.set(reelP).mulAdd(rgt, -0.1f).mulAdd(up, cos(spin) * 0.07f).mulAdd(fwd, sin(spin) * 0.07f)
        wr.set(reelP).mulAdd(rgt, -0.05f); seg(rodB, wr, knobP, 0.012f); ball(rodB, knobP, 0.04f, 0.04f, 0.04f, rot)
        wr.set(rp[2]).mulAdd(dirT, -0.05f); el.set(rp[2]).mulAdd(dirT, 0.05f); seg(blueB, wr, el, 0.042f)
        for (i in intArrayOf(3, 5, 7)) ball(silverB, rp[i], 0.035f, 0.035f, 0.035f, rot)

        // Dangling line + bobber (floats on the water)
        if (!init) { bp.set(rp[7]).y -= 0.9f; bq.set(bp) }
        when (mode) {
            1 -> {
                bv.y -= 9.8f * dt; bp.mulAdd(bv, dt)
                val gnd = ground(bp.x, bp.z)
                if (bp.y <= 0f && gnd < -0.2f) { mode = 2; landed = 1; bp.y = 0f }
                else if (bp.y <= gnd) { landed = 2; bp.y = gnd }
                bq.set(bp)
            }
            2 -> { bp.y = -dip + sin(time * 2f) * 0.03f; bq.set(bp) }
            else -> {
                a.set(bp).sub(bq).scl(0.985f); bq.set(bp); bp.add(a); bp.y -= 9.8f * dt * dt
                d.set(bp).sub(rp[7]); val l = d.len(); if (l > 0.9f) bp.set(rp[7]).mulAdd(d, 0.9f / l)
                if (bp.y < 0f) bp.y = 0f
            }
        }
        if (mode == 3) {
            dn.set(Vector3.Y).mulAdd(rgt, sin(time * 14f) * 0.35f * hookAmp).nor()
            hookP.set(bp).y -= 0.32f; drawFish(hookP, dn, fwd, time, hookAmp); hookAmp = max(0.4f, hookAmp - dt * 0.05f)
        }
        seg(lineC, rp[7], bp, 0.004f); ball(redB, bp, 0.05f, 0.16f, 0.04f, rot)
        if (fishMode == 1) {
            val ph = time * 14f
            t.set(hp[0]).mulAdd(fwd, 0.22f).mulAdd(up, 0.1f).mulAdd(rgt, sin(ph) * 0.05f * fishAmp).mulAdd(up, sin(ph * 1.3f) * 0.04f * fishAmp)
            a.set(t).sub(fp).scl(120f).mulAdd(fv, -14f); fv.mulAdd(a, dt); fp.mulAdd(fv, dt)
            fishAmp = max(0.35f, fishAmp - dt * 0.03f)
            dn.set(fwd).mulAdd(rgt, sin(ph) * 0.5f * fishAmp).nor()
            drawFish(fp, dn, up, time, fishAmp)
        } else if (fishMode == 2) {
            fishT += dt; fv.y -= 9.8f * dt; fp.mulAdd(fv, dt)
            if (abs(fv.x) + abs(fv.z) > 0.3f) fh.set(fv.x, 0f, fv.z).nor()
            val gnd = ground(fp.x, fp.z)
            if (fp.y <= 0f && gnd < -0.2f) {
                fv.set(0f, 0f, 0f); fp.mulAdd(fh, dt * 1.2f)
                fp.y = if (fishT > 3f) max(-1.6f, -(fishT - 3f) * 0.5f) else sin(time * 3f) * 0.03f
            } else if (fp.y <= gnd + 0.08f) {
                fp.y = gnd + 0.08f; fv.y = if (fv.y < -1f) -fv.y * 0.35f else 0f; fv.x *= 0.85f; fv.z *= 0.85f
                if (Random.nextFloat() < dt * 2.5f) fv.y = 2.5f
            }
            drawFish(fp, fh, Vector3.Y, time, 1f)
            if (fishT > 9f) fishMode = 0
        }

        // Hexagonal body (visible when looking down): torso + legs
        q.setFromAxis(Vector3.Y, yaw)
        val ys = sin(yaw * 0.0174533f); val yc = cos(yaw * 0.0174533f)
        tmp.set(eye.x + ys * 0.12f, eye.y - 0.7f, eye.z + yc * 0.12f); ball(hexS, tmp, 0.5f, 0.75f, 0.34f, q)
        for (sd2 in intArrayOf(-1, 1)) {
            tmp.set(eye.x + ys * 0.12f + yc * 0.13f * sd2, eye.y - 1.2f, eye.z + yc * 0.12f - ys * 0.13f * sd2)
            ball(hexP, tmp, 0.22f, 0.8f, 0.22f, q)
            tmp.y = eye.y - 1.55f; ball(hexB, tmp, 0.24f, 0.12f, 0.36f, q)
        }

        init = true
        for (p in pools) for (j in 0 until p.n) out += p.l[j]
    }
}
