package com.dazed.fishing3d

import android.os.Bundle
import com.badlogic.gdx.backends.android.AndroidApplication
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration

class MainActivity : AndroidApplication() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initialize(FishGame(), AndroidApplicationConfiguration().apply { useImmersiveMode = true; numSamples = 2 })
    }
}
