plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

val gdx = "1.12.1"
val natives by configurations.creating

android {
    namespace = "com.dazed.fishing3d"
    compileSdk = 34
    defaultConfig { applicationId = "com.dazed.fishing3d"; minSdk = 24; targetSdk = 34; versionCode = 1; versionName = "0.1" }
    sourceSets["main"].jniLibs.srcDir("libs")
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.badlogicgames.gdx:gdx:$gdx")
    implementation("com.badlogicgames.gdx:gdx-backend-android:$gdx")
    for (abi in listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64"))
        natives("com.badlogicgames.gdx:gdx-platform:$gdx:natives-$abi")
}

tasks.register("copyAndroidNatives") {
    doFirst {
        natives.files.forEach { jar ->
            val abi = jar.name.substringAfter("natives-").removeSuffix(".jar")
            copy { from(zipTree(jar)); into(file("libs/$abi")); include("*.so") }
        }
    }
}
tasks.matching { it.name.contains("JniLibFolders") }.configureEach { dependsOn("copyAndroidNatives") }
