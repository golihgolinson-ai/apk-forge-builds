plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.chaquo.python")
}

android {
    namespace = "com.studiopy"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.studiopy"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    buildFeatures { compose = true }
    androidResources { noCompress += "apk" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources.excludes += listOf("META-INF/*.version", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*") }
}

chaquopy { defaultConfig { version = "3.12" } }

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.android.tools.build:apksig:8.7.3")
    implementation("org.bouncycastle:bcpkix-jdk18on:1.78.1")
    implementation("com.github.REAndroid:ARSCLib:1.3.5")
}

// Собираем :template и кладём как assets/template.apk — отдельных шагов не нужно.
val copyTemplate by tasks.registering(Copy::class) {
    dependsOn(":template:assembleRelease")
    from(project(":template").layout.buildDirectory.dir("outputs/apk/release")) {
        include("template-release.apk")
        rename { "template.apk" }
    }
    into(layout.projectDirectory.dir("src/main/assets"))
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(copyTemplate) }
