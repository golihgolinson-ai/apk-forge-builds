package com.studiopy

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.sin
import kotlin.random.Random

/** Кнопка/карточка с упругим нажатием. */
fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.95f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "bounce")
    this.scale(s).clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun GradientBox(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "grad")
    val shift by t.animateFloat(0f, 1f, infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Reverse), label = "shift")
    Box(
        modifier.clip(RoundedCornerShape(24.dp)).background(
            Brush.linearGradient(
                listOf(Violet, Pink, Cyan),
                start = Offset(0f, 0f),
                end = Offset(500f + 900f * shift, 300f + 600f * shift),
            )
        ),
        content = content,
    )
}

@Composable
fun BobbingEmoji(emoji: String, size: Int = 44) {
    val t = rememberInfiniteTransition(label = "bob")
    val dy by t.animateFloat(-6f, 6f, infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "dy")
    val rot by t.animateFloat(-8f, 8f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "rot")
    Text(emoji, fontSize = size.sp,
        modifier = Modifier.offset(y = dy.dp).rotate(rot))
}

@Composable
fun TopBar(title: String, onBack: (() -> Unit)?, actions: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
        Text(
            title, Modifier.weight(1f).padding(start = if (onBack == null) 12.dp else 0.dp),
            style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
        actions()
    }
}

@Composable
fun NameDialog(title: String, initial: String, label: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, label = { Text(label) }, singleLine = true) },
        confirmButton = { TextButton({ if (v.isNotBlank()) onOk(v.trim()) }) { Text("OK") } },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } },
    )
}

private class Particle(val x: Float, val y0: Float, val speed: Float, val color: Color, val phase: Float)

@Composable
fun Confetti(modifier: Modifier = Modifier) {
    val colors = listOf(Violet, Pink, Cyan, Green, Color(0xFFFFC857))
    val parts = remember {
        List(70) { Particle(Random.nextFloat(), Random.nextFloat() * -0.4f, Random.nextFloat() + 0.8f, colors.random(), Random.nextFloat() * 6f) }
    }
    var t by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (t < 1f) withFrameNanos { n -> t = ((n - start) / 2.6e9).toFloat().coerceAtMost(1f) }
    }
    Canvas(modifier.fillMaxSize()) {
        parts.forEach { p ->
            val y = (p.y0 + t * p.speed * 1.3f) * size.height
            if (y in 0f..size.height) {
                drawRect(
                    p.color.copy(alpha = 1f - t * 0.5f),
                    Offset(p.x * size.width + sin(t * 8f + p.phase) * 24f, y),
                    Size(10f, 16f),
                )
            }
        }
    }
}
