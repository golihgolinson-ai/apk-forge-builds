package com.studiopy

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface BuildState {
    object Idle : BuildState
    data class Running(val stage: Int) : BuildState
    data class Done(val apk: File) : BuildState
    data class Failed(val msg: String) : BuildState
}

private val PKG_RE = Regex("^[a-z][a-z0-9_]*(\\.[a-z][a-z0-9_]*)+$")

@Composable
fun BuildScreen(app: AppState, project: File) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val saved = remember(project) { app.store.meta(project) }
    var name by remember { mutableStateOf(saved.appName) }
    var pkg by remember { mutableStateOf(saved.pkg) }
    var st by remember { mutableStateOf<BuildState>(BuildState.Idle) }
    val pkgOk = PKG_RE.matches(pkg)
    val running = st is BuildState.Running

    fun start() {
        val meta = Meta(name.trim(), pkg.trim())
        app.store.saveMeta(project, meta)
        st = BuildState.Running(0)
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val out = File(ctx.getExternalFilesDir("apk"), "${project.name}.apk")
                    app.builder.build(project, meta, out) { st = BuildState.Running(it) }
                }
            }
            st = r.fold({ BuildState.Done(it) }, { BuildState.Failed(it.message ?: it.toString()) })
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            TopBar("Сборка APK", { if (!running) app.back() })
            AnimatedContent(
                st, Modifier.weight(1f).fillMaxWidth(), label = "build",
                contentKey = { it::class },
                transitionSpec = { (fadeIn(tween(300)) + scaleIn(initialScale = .96f)) togetherWith fadeOut(tween(200)) },
            ) { s ->
                when (s) {
                    is BuildState.Idle, is BuildState.Failed -> Column(
                        Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
                    ) {
                        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Название приложения") })
                        OutlinedTextField(
                            pkg, { pkg = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Package name") },
                            isError = !pkgOk, supportingText = { Text(if (pkgOk) "Уникальный id приложения" else "Формат: com.example.myapp (строчные латинские)") },
                        )
                        if (s is BuildState.Failed) Card(colors = CardDefaults.cardColors(containerColor = Pink.copy(alpha = .15f))) {
                            Text("Ошибка: ${s.msg}", Modifier.padding(12.dp), color = Pink)
                        }
                        Button({ start() }, Modifier.fillMaxWidth().height(54.dp), enabled = pkgOk && name.isNotBlank()) {
                            Icon(Icons.Default.Android, null); Spacer(Modifier.width(8.dp)); Text("Собрать", fontSize = 17.sp)
                        }
                    }
                    is BuildState.Running -> Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        val p by animateFloatAsState((s.stage + 1f) / STAGES.size, tween(500), label = "p")
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(vertical = 24.dp)) {
                            CircularProgressIndicator({ p }, Modifier.size(120.dp), strokeWidth = 8.dp, color = Violet)
                            BobbingEmoji("🔨", 40)
                        }
                        STAGES.forEachIndexed { i, title -> StageRow(title, if (i < s.stage) 2 else if (i == s.stage) 1 else 0) }
                    }
                    is BuildState.Done -> Box(Modifier.fillMaxSize()) {
                        Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                            var pop by remember { mutableStateOf(false) }
                            LaunchedEffect(Unit) { pop = true }
                            val sc by animateFloatAsState(if (pop) 1f else 0f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "pop")
                            Box(Modifier.size(110.dp).scale(sc).clip(CircleShape).background(Green), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.Check, null, Modifier.size(64.dp), tint = Color.White)
                            }
                            Spacer(Modifier.height(20.dp))
                            Text("APK готов!", style = MaterialTheme.typography.headlineMedium)
                            Text("${s.apk.name} · ${humanSize(s.apk.length())}", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(24.dp))
                            Button({ installApk(ctx, s.apk) }, Modifier.fillMaxWidth().height(52.dp)) {
                                Icon(Icons.Default.GetApp, null); Spacer(Modifier.width(8.dp)); Text("Установить")
                            }
                            Spacer(Modifier.height(10.dp))
                            OutlinedButton({ shareFile(ctx, s.apk, "application/vnd.android.package-archive") }, Modifier.fillMaxWidth().height(52.dp)) {
                                Icon(Icons.Default.Share, null); Spacer(Modifier.width(8.dp)); Text("Поделиться")
                            }
                            TextButton({ st = BuildState.Idle }) { Text("Собрать заново") }
                        }
                        Confetti()
                    }
                }
            }
        }
    }
}

@Composable
private fun StageRow(title: String, state: Int) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        AnimatedContent(
            state, Modifier.size(28.dp), label = "stage",
            transitionSpec = { (scaleIn() + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
        ) { s ->
            when (s) {
                2 -> Icon(Icons.Default.CheckCircle, null, tint = Green)
                1 -> CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp)
                else -> Icon(Icons.Outlined.RadioButtonUnchecked, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.width(12.dp))
        val a by animateFloatAsState(if (state == 0) .5f else 1f, label = "a")
        Text(title, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurface.copy(alpha = a))
    }
}
