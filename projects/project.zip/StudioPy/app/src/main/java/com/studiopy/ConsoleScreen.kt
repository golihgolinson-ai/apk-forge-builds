package com.studiopy

import android.os.Handler
import android.os.Looper
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chaquo.python.Python
import java.io.File
import kotlin.concurrent.thread

class ConsoleSink(private val post: (String, Boolean) -> Unit) {
    fun append(text: String, err: Boolean) = post(text, err)
}

/** Запуск main.py прямо в StudioPy (Chaquopy) — вывод в «терминале». */
@Composable
fun ConsoleScreen(app: AppState, project: File) {
    var out by remember { mutableStateOf(AnnotatedString("")) }
    var running by remember { mutableStateOf(false) }
    val scroll = rememberScrollState()
    val ui = remember { Handler(Looper.getMainLooper()) }

    fun runIt() {
        if (running) return
        val main = File(project, "main.py")
        out = AnnotatedString(""); running = true
        if (!main.exists()) {
            out = buildAnnotatedString { withStyle(SpanStyle(color = Pink)) { append("Нет main.py в корне проекта\n") } }
            running = false; return
        }
        val sink = ConsoleSink { text, err ->
            ui.post {
                out = buildAnnotatedString {
                    append(out)
                    withStyle(SpanStyle(color = if (err) Pink else Color(0xFFD7D9F0))) { append(text) }
                }.let { if (it.length > 60_000) it.subSequence(it.length - 60_000, it.length) else it }
            }
        }
        thread {
            runCatching { Python.getInstance().getModule("runner").callAttr("run", main.path, sink) }
                .onFailure { e -> sink.append("\n${e.message}\n", true) }
            ui.post { running = false }
        }
    }

    LaunchedEffect(project) { runIt() }
    LaunchedEffect(out.length) { scroll.animateScrollTo(scroll.maxValue) }

    val blink by rememberInfiniteTransition(label = "blink")
        .animateFloat(0.2f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse), label = "b")

    Column(Modifier.fillMaxSize()) {
        TopBar("Консоль · ${project.name}", { app.back() }) {
            IconButton({ out = AnnotatedString("") }) { Icon(Icons.Default.DeleteSweep, "Очистить") }
            IconButton({ runIt() }, enabled = !running) { Icon(Icons.Default.PlayArrow, "Запуск", tint = if (running) MaterialTheme.colorScheme.onSurfaceVariant else Green) }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().padding(12.dp).clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0B0C14)).verticalScroll(scroll).padding(14.dp),
        ) {
            Text(out, fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp, color = Color(0xFFD7D9F0))
            if (running) Text("▌", color = Green, fontFamily = FontFamily.Monospace, modifier = Modifier.alpha(blink))
            else Text("\n— процесс завершён —", color = Color(0xFF6C7090), fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        }
    }
}
