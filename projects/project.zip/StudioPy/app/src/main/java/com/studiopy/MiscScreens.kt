package com.studiopy

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ApksScreen(app: AppState) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val files = remember(tick) {
        ctx.getExternalFilesDir("apk")?.listFiles()?.filter { it.extension == "apk" }?.sortedByDescending { it.lastModified() } ?: emptyList()
    }
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize()) {
        TopBar("Мои APK", { app.back() })
        if (files.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    BobbingEmoji("📭", 56); Spacer(Modifier.height(8.dp)); Text("Пока ничего не собрано")
                }
            }
        } else LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(files, key = { it.name }) { f ->
                Card(Modifier.fillMaxWidth().animateItem(), shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🤖", fontSize = 28.sp)
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text(f.name, style = MaterialTheme.typography.titleSmall)
                            Text("${humanSize(f.length())} · ${fmt.format(Date(f.lastModified()))}", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton({ installApk(ctx, f) }) { Icon(Icons.Default.GetApp, "Установить", tint = Green) }
                        IconButton({ shareFile(ctx, f, "application/vnd.android.package-archive") }) { Icon(Icons.Default.Share, "Поделиться") }
                        IconButton({ f.delete(); tick++ }) { Icon(Icons.Default.Delete, "Удалить") }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(app: AppState) {
    Column(Modifier.fillMaxSize()) {
        TopBar("Настройки", { app.back() })
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.DarkMode, null)
                Text("Тёмная тема", Modifier.weight(1f).padding(start = 12.dp))
                Switch(app.dark, { app.setDark(it) })
            }
            Column {
                Text("Размер шрифта редактора: ${app.fontSize.toInt()}")
                Slider(app.fontSize, { app.setFont(it) }, valueRange = 10f..22f, steps = 11)
            }
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Text(
                    "Как работает сборка: StudioPy берёт шаблон с Python, меняет название и package, " +
                        "кладёт твои файлы в assets/pyproject и подписывает APK локальным ключом. " +
                        "Библиотеки pip вшиваются в шаблон заранее (template/build.gradle.kts).",
                    Modifier.padding(14.dp), style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}
