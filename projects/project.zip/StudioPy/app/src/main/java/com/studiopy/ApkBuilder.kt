package com.studiopy

import android.content.Context
import com.android.apksig.ApkSigner
import com.reandroid.apk.ApkModule
import com.reandroid.arsc.io.ByteInputSource
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Date

val STAGES = listOf("Распаковка шаблона", "Правка манифеста", "Добавление файлов", "Упаковка APK", "Подпись APK")

/**
 * Сборка APK из шаблона (assets/template.apk — оболочка с Python):
 * меняем package/название, кладём файлы проекта в assets/pyproject/, подписываем.
 * ВНИМАНИЕ: не компилировалось. Вызовы ARSCLib проверь по её документации.
 */
class ApkBuilder(private val ctx: Context) {

    fun build(project: File, meta: Meta, out: File, onStage: (Int) -> Unit): File {
        check(ctx.assets.list("")?.contains("template.apk") == true) {
            "Нет assets/template.apk — собери проект целиком (:app:assembleRelease), шаблон соберётся сам"
        }
        out.parentFile?.mkdirs()
        val pause = { Thread.sleep(350) }

        onStage(0)
        val template = File(ctx.cacheDir, "template.apk")
        ctx.assets.open("template.apk").use { i -> template.outputStream().use { i.copyTo(it) } }
        val module = ApkModule.loadApkFile(template)
        module.apkSignatureBlock = null
        module.removeDir("META-INF")
        module.removeDir("assets/pyproject")
        pause()

        onStage(1)
        module.androidManifest.packageName = meta.pkg
        module.androidManifest.applicationLabel = meta.appName
        pause()

        onStage(2)
        project.walkTopDown()
            .filter { it.isFile && it.name != META && "__pycache__" !in it.path }
            .forEach { f ->
                val path = "assets/pyproject/" + f.relativeTo(project).invariantSeparatorsPath
                module.add(ByteInputSource(f.readBytes(), path))
            }
        pause()

        onStage(3)
        val unsigned = File(ctx.cacheDir, "unsigned.apk")
        module.writeApk(unsigned)
        pause()

        onStage(4)
        sign(unsigned, out)
        pause()
        return out
    }

    private fun sign(input: File, out: File) {
        val (key, cert) = loadOrCreateKey()
        val signer = ApkSigner.SignerConfig.Builder("studiopy", key, listOf(cert)).build()
        ApkSigner.Builder(listOf(signer))
            .setInputApk(input).setOutputApk(out)
            .setV1SigningEnabled(false).setV2SigningEnabled(true).setV3SigningEnabled(true)
            .setMinSdkVersion(26)
            .build().sign()
    }

    private fun loadOrCreateKey(): Pair<PrivateKey, X509Certificate> {
        val file = File(ctx.filesDir, "studiopy.p12")
        val pass = "studiopy".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        if (file.exists()) {
            file.inputStream().use { ks.load(it, pass) }
        } else {
            ks.load(null, null)
            val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
            val name = X500Name("CN=StudioPy")
            val now = System.currentTimeMillis()
            val holder = JcaX509v3CertificateBuilder(
                name, BigInteger.valueOf(now), Date(now), Date(now + 30L * 365 * 24 * 3600 * 1000), name, kp.public
            ).build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private))
            val cert = JcaX509CertificateConverter().getCertificate(holder)
            ks.setKeyEntry("key", kp.private, pass, arrayOf(cert))
            file.outputStream().use { ks.store(it, pass) }
        }
        return (ks.getKey("key", pass) as PrivateKey) to (ks.getCertificate("key") as X509Certificate)
    }
}
