package com.studiopy

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color

val Violet = Color(0xFF7C5CFF)
val Cyan = Color(0xFF22D3EE)
val Pink = Color(0xFFFF5CAA)
val Green = Color(0xFF34D399)

@Composable
fun StudioTheme(dark: Boolean, content: @Composable () -> Unit) {
    val bg by animateColorAsState(if (dark) Color(0xFF0E0F1A) else Color(0xFFF4F2FF), tween(500), label = "bg")
    val surface by animateColorAsState(if (dark) Color(0xFF181A2C) else Color.White, tween(500), label = "sf")
    val on by animateColorAsState(if (dark) Color(0xFFEDEBFF) else Color(0xFF1B1B2F), tween(500), label = "on")
    val base = if (dark) darkColorScheme() else lightColorScheme()
    val scheme = base.copy(
        primary = Violet, secondary = Cyan, tertiary = Pink,
        background = bg, surface = surface, surfaceVariant = surface,
        onBackground = on, onSurface = on, onSurfaceVariant = on.copy(alpha = .7f),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}
