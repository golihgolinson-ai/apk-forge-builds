package com.studiopy

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

sealed class Screen(val depth: Int) {
    object Projects : Screen(0)
    object Apks : Screen(1)
    object Settings : Screen(1)
    data class Files(val p: File) : Screen(1)
    data class Editor(val p: File, val f: File) : Screen(2)
    data class Build(val p: File) : Screen(2)
    data class Console(val p: File) : Screen(2)
}

class AppState(val ctx: Context) {
    val store = ProjectStore(ctx)
    val builder = ApkBuilder(ctx)
    private val prefs = ctx.getSharedPreferences("studiopy", 0)

    var dark by mutableStateOf(prefs.getBoolean("dark", true)); private set
    var fontSize by mutableFloatStateOf(prefs.getFloat("font", 14f)); private set
    var projects by mutableStateOf(store.projects())
    var version by mutableIntStateOf(0)
    var screen by mutableStateOf<Screen>(Screen.Projects)

    fun setDark(v: Boolean) { dark = v; prefs.edit().putBoolean("dark", v).apply() }
    fun setFont(v: Float) { fontSize = v; prefs.edit().putFloat("font", v).apply() }
    fun reloadProjects() { projects = store.projects(); version++ }
    fun bump() { version++ }
    fun go(s: Screen) { screen = s }
    fun back() {
        screen = when (val s = screen) {
            is Screen.Editor -> Screen.Files(s.p)
            is Screen.Build -> Screen.Files(s.p)
            is Screen.Console -> Screen.Files(s.p)
            else -> Screen.Projects
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        val app = AppState(this)
        if (app.projects.isEmpty()) { app.store.create("MyApp", Templates.all[1]); app.reloadProjects() }
        setContent {
            StudioTheme(app.dark) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { Root(app) }
            }
        }
    }
}

@Composable
fun Root(app: AppState) {
    BackHandler(app.screen != Screen.Projects) { app.back() }
    Box(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        AnimatedContent(
            targetState = app.screen,
            transitionSpec = {
                when {
                    targetState.depth == initialState.depth -> fadeIn(tween(220)) togetherWith fadeOut(tween(220))
                    targetState.depth > initialState.depth ->
                        (slideInHorizontally(tween(320)) { it / 3 } + fadeIn(tween(320))) togetherWith
                            (slideOutHorizontally(tween(320)) { -it / 3 } + fadeOut(tween(200)))
                    else ->
                        (slideInHorizontally(tween(320)) { -it / 3 } + fadeIn(tween(320))) togetherWith
                            (slideOutHorizontally(tween(320)) { it / 3 } + fadeOut(tween(200)))
                }
            },
            label = "nav",
        ) { s ->
            when (s) {
                Screen.Projects -> ProjectsScreen(app)
                Screen.Apks -> ApksScreen(app)
                Screen.Settings -> SettingsScreen(app)
                is Screen.Files -> FilesScreen(app, s.p)
                is Screen.Editor -> EditorScreen(app, s.p, s.f)
                is Screen.Build -> BuildScreen(app, s.p)
                is Screen.Console -> ConsoleScreen(app, s.p)
            }
        }
    }
}
