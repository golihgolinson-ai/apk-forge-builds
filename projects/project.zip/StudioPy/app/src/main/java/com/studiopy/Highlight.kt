package com.studiopy

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation

/** Простая подсветка Python регулярками. */
class PythonHighlighter(dark: Boolean) : VisualTransformation {
    private val cKeyword = if (dark) Color(0xFFFF79C6) else Color(0xFFC2185B)
    private val cString = if (dark) Color(0xFFF1FA8C) else Color(0xFF8A6D00)
    private val cComment = if (dark) Color(0xFF7C819E) else Color(0xFF8E92A8)
    private val cNumber = if (dark) Color(0xFFBD93F9) else Color(0xFF6A3FD0)
    private val cBuiltin = if (dark) Color(0xFF8BE9FD) else Color(0xFF00839A)
    private val cDef = if (dark) Color(0xFF50FA7B) else Color(0xFF1B8A4B)

    private val kw = Regex("\\b(def|class|import|from|as|if|elif|else|for|while|return|in|not|and|or|is|None|True|False|try|except|finally|with|lambda|pass|break|continue|raise|yield|global|async|await)\\b")
    private val builtin = Regex("\\b(print|len|range|str|int|float|list|dict|set|tuple|open|input|type|sum|min|max|sorted|enumerate|zip|map|filter)\\b")
    private val num = Regex("\\b\\d+(\\.\\d+)?\\b")
    private val defName = Regex("(?<=def |class )\\w+")
    private val str = Regex("\"\"\"[\\s\\S]*?\"\"\"|'''[\\s\\S]*?'''|\"[^\"\\n]*\"|'[^'\\n]*'")
    private val comment = Regex("#.*")

    override fun filter(text: AnnotatedString): TransformedText {
        val s = text.text
        val b = AnnotatedString.Builder(s)
        fun paint(r: Regex, c: Color) = r.findAll(s).forEach {
            b.addStyle(SpanStyle(color = c), it.range.first, it.range.last + 1)
        }
        paint(num, cNumber); paint(builtin, cBuiltin); paint(kw, cKeyword); paint(defName, cDef)
        paint(str, cString); paint(comment, cComment)
        return TransformedText(b.toAnnotatedString(), OffsetMapping.Identity)
    }
}
