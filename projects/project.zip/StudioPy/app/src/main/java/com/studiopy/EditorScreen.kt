package com.studiopy

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun EditorScreen(app: AppState, project: File, file: File) {
    var tf by remember(file) { mutableStateOf(TextFieldValue(file.readText())) }
    var dirty by remember(file) { mutableStateOf(false) }
    val undo = remember(file) { ArrayDeque<TextFieldValue>() }
    val latest by rememberUpdatedState(tf)
    DisposableEffect(file) { onDispose { runCatching { file.writeText(latest.text) } } }

    fun change(n: TextFieldValue) {
        var v = n
        // автоотступ после Enter (+4 пробела после «:»)
        if (n.text.length == tf.text.length + 1 && n.selection.collapsed && n.selection.start > 0 &&
            n.text[n.selection.start - 1] == '\n'
        ) {
            val line = n.text.substring(0, n.selection.start - 1).substringAfterLast('\n')
            var indent = line.takeWhile { it == ' ' }
            if (line.trimEnd().endsWith(":")) indent += "    "
            val pos = n.selection.start
            v = n.copy(text = n.text.substring(0, pos) + indent + n.text.substring(pos), selection = TextRange(pos + indent.length))
        }
        if (v.text != tf.text) {
            undo.addLast(tf); if (undo.size > 100) undo.removeFirst(); dirty = true
        }
        tf = v
    }
    fun insert(s: String) {
        val sel = tf.selection
        change(TextFieldValue(tf.text.replaceRange(sel.min, sel.max, s), TextRange(sel.min + s.length)))
    }
    fun save() { file.writeText(tf.text); dirty = false; app.bump() }

    val dot by animateColorAsState(if (dirty) Pink else Green, tween(300), label = "dot")
    val fs = app.fontSize
    val mono = TextStyle(fontFamily = FontFamily.Monospace, fontSize = fs.sp, lineHeight = (fs * 1.5f).sp, color = MaterialTheme.colorScheme.onSurface)
    val isPy = file.extension == "py"
    val vt = remember(app.dark, isPy) { if (isPy) PythonHighlighter(app.dark) else VisualTransformation.None }
    val lines = tf.text.count { it == '\n' } + 1
    val minW = LocalConfiguration.current.screenWidthDp.dp - 64.dp
    val minH = LocalConfiguration.current.screenHeightDp.dp * 0.6f

    Column(Modifier.fillMaxSize()) {
        TopBar(file.name, { app.back() }) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
            IconButton({ undo.removeLastOrNull()?.let { tf = it } }, enabled = undo.isNotEmpty()) { Icon(Icons.Default.Undo, "Отмена") }
            IconButton({ save() }) { Icon(Icons.Default.Save, "Сохранить") }
            if (isPy) IconButton({ save(); app.go(Screen.Console(project)) }) { Icon(Icons.Default.PlayArrow, "Запустить", tint = Green) }
        }
        Row(
            Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surface).verticalScroll(rememberScrollState())
                .heightIn(min = minH),
        ) {
            Text(
                (1..lines).joinToString("\n"),
                Modifier.padding(start = 10.dp, end = 8.dp, top = 12.dp).widthIn(min = 24.dp),
                style = mono.copy(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = .5f)),
            )
            Box(Modifier.weight(1f).horizontalScroll(rememberScrollState())) {
                BasicTextField(
                    tf, { change(it) },
                    Modifier.widthIn(min = minW).padding(top = 12.dp, end = 16.dp, bottom = 80.dp),
                    textStyle = mono, cursorBrush = SolidColor(Violet), visualTransformation = vt, softWrap = false,
                )
            }
        }
        LazyRow(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            contentPadding = PaddingValues(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(listOf("⇥", ":", "(", ")", "[", "]", "{", "}", "\"", "'", "=", "#", "_", ".", ",")) { k ->
                Box(
                    Modifier.size(width = 40.dp, height = 40.dp).clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .bounceClick { insert(if (k == "⇥") "    " else k) },
                    contentAlignment = Alignment.Center,
                ) { Text(k, fontFamily = FontFamily.Monospace, style = MaterialTheme.typography.titleMedium) }
            }
        }
    }
}
