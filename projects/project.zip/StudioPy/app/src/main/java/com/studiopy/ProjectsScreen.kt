package com.studiopy

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun ProjectsScreen(app: AppState) {
    var creating by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<File?>(null) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 12.dp, 16.dp, 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                GradientBox(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        BobbingEmoji("🐍", 46)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("StudioPy", fontSize = 26.sp, color = Color.White, style = MaterialTheme.typography.headlineSmall)
                            Text("Python → APK прямо на телефоне", color = Color.White.copy(alpha = .85f))
                        }
                        IconButton({ app.go(Screen.Apks) }) { Icon(Icons.Default.Android, null, tint = Color.White) }
                        IconButton({ app.go(Screen.Settings) }) { Icon(Icons.Default.Settings, null, tint = Color.White) }
                    }
                }
            }
            itemsIndexed(app.projects, key = { _, p -> p.name }) { i, p ->
                ProjectCard(app, p, i, Modifier.animateItem()) { deleting = p }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { creating = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp),
            icon = { Icon(Icons.Default.Add, null) },
            text = { Text("Новый проект") },
        )
    }

    if (creating) NewProjectDialog(app, { creating = false })
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Удалить «${p.name}»?") },
            text = { Text("Все файлы проекта будут удалены.") },
            confirmButton = { TextButton({ app.store.deleteProject(p); app.reloadProjects(); deleting = null }) { Text("Удалить") } },
            dismissButton = { TextButton({ deleting = null }) { Text("Отмена") } },
        )
    }
}

@Composable
private fun ProjectCard(app: AppState, p: File, index: Int, modifier: Modifier, onDelete: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(index * 70L); shown = true }
    AnimatedVisibility(
        shown, modifier,
        enter = fadeIn() + slideInVertically { it / 2 } + scaleIn(initialScale = .92f),
    ) {
        val meta = remember(app.version, p) { app.store.meta(p) }
        val count = remember(app.version, p) { app.store.userFiles(p).size }
        Card(
            Modifier.fillMaxWidth().bounceClick { app.go(Screen.Files(p)) },
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(2.dp),
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).background(Violet.copy(alpha = .15f), RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                ) { Text("🐍", fontSize = 24.sp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium)
                    Text(meta.pkg, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$count файл(ов)", style = MaterialTheme.typography.labelSmall, color = Cyan)
                }
                IconButton(onDelete) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        }
    }
}

@Composable
private fun NewProjectDialog(app: AppState, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var sel by remember { mutableIntStateOf(1) }
    val clash = app.projects.any { it.name.equals(name.trim(), true) }
    val bad = name.isNotBlank() && (clash || name.any { it in "/\\:*?\"<>|" })
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новый проект") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(name, { name = it }, singleLine = true, label = { Text("Название") }, isError = bad,
                    supportingText = { if (bad) Text("Имя занято или содержит недопустимые символы") })
                Text("Шаблон", style = MaterialTheme.typography.labelLarge)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(Templates.all.size) { i ->
                        val t = Templates.all[i]
                        val selected = i == sel
                        val border by animateColorAsState(if (selected) Violet else Color.Transparent, label = "b")
                        val sc by animateFloatAsState(if (selected) 1.05f else 1f, label = "s")
                        Card(
                            Modifier.width(110.dp).graphicsScale(sc).border(2.dp, border, RoundedCornerShape(16.dp)).bounceClick { sel = i },
                            shape = RoundedCornerShape(16.dp),
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text(t.emoji, fontSize = 24.sp)
                                Text(t.title, style = MaterialTheme.typography.labelLarge)
                                Text(t.desc, style = MaterialTheme.typography.labelSmall, maxLines = 2)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(enabled = name.isNotBlank() && !bad, onClick = {
                val dir = app.store.create(name, Templates.all[sel])
                app.reloadProjects(); onDismiss(); app.go(Screen.Files(dir))
            }) { Text("Создать") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Отмена") } },
    )
}

private fun Modifier.graphicsScale(s: Float) = this.then(Modifier.scale(s))
