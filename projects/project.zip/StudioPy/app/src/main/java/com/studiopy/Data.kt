package com.studiopy

import android.content.Context
import java.io.File
import java.util.Properties
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

const val META = ".studiopy"

data class Meta(val appName: String, val pkg: String)
data class Node(val file: File, val rel: String, val depth: Int, val isDir: Boolean)
data class Template(val title: String, val emoji: String, val desc: String, val files: Map<String, String>)

object Templates {
    val all = listOf(
        Template("Пустой", "📄", "Один main.py", mapOf(
            "main.py" to "print(\"Hello from StudioPy\")\n"
        )),
        Template("Пакет", "📦", "Модули и папки", mapOf(
            "main.py" to """
                import json
                from app.greet import hello

                cfg = json.load(open("data/config.json"))
                print(hello(cfg["name"]))
            """.trimIndent() + "\n",
            "app/__init__.py" to "",
            "app/greet.py" to "def hello(name):\n    return f\"Привет, {name}!\"\n",
            "data/config.json" to "{\"name\": \"StudioPy\"}\n",
        )),
        Template("Калькулятор", "🧮", "Вычисления и math", mapOf(
            "main.py" to """
                import math

                def calc(expr):
                    names = {k: getattr(math, k) for k in dir(math) if not k.startswith("_")}
                    return eval(expr, {"__builtins__": {}}, names)

                for e in ["2 + 2 * 3", "sqrt(144)", "sin(pi / 2)", "2 ** 10"]:
                    print(f"{e} = {calc(e)}")
            """.trimIndent() + "\n"
        )),
        Template("HTTP", "🌐", "requests + интернет", mapOf(
            "main.py" to """
                import requests

                r = requests.get("https://api.github.com/zen", timeout=10)
                print(r.status_code, r.text)
            """.trimIndent() + "\n"
        )),
        Template("Android API", "🤖", "Toast через Chaquopy", mapOf(
            "main.py" to """
                from java import jclass, dynamic_proxy
                from com.chaquo.python import Python

                Toast = jclass("android.widget.Toast")
                Handler = jclass("android.os.Handler")
                Looper = jclass("android.os.Looper")
                Runnable = jclass("java.lang.Runnable")


                class Task(dynamic_proxy(Runnable)):
                    def __init__(self, fn):
                        super().__init__()
                        self.fn = fn

                    def run(self):
                        self.fn()


                ctx = Python.getPlatform().getApplication()


                def toast(msg):
                    Handler(Looper.getMainLooper()).post(
                        Task(lambda: Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()))


                toast("Привет из Python!")
                print("Toast показан")
            """.trimIndent() + "\n"
        )),
    )
}

class ProjectStore(ctx: Context) {
    val root = File(ctx.filesDir, "projects").apply { mkdirs() }

    fun projects(): List<File> =
        root.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name.lowercase() } ?: emptyList()

    fun create(name: String, t: Template): File {
        val clean = name.trim()
        val dir = File(root, clean).apply { mkdirs() }
        t.files.forEach { (p, c) -> File(dir, p).apply { parentFile?.mkdirs(); writeText(c) } }
        var seg = clean.lowercase().filter { it.isLetterOrDigit() && it.code < 128 }.ifEmpty { "app" }
        if (seg.first().isDigit()) seg = "a$seg"
        saveMeta(dir, Meta(clean, "com.studiopy.$seg"))
        return dir
    }

    fun deleteProject(p: File) = p.deleteRecursively()

    fun meta(dir: File): Meta {
        val p = Properties()
        File(dir, META).takeIf { it.exists() }?.inputStream()?.use { p.load(it) }
        return Meta(p.getProperty("name", dir.name), p.getProperty("package", "com.studiopy.app"))
    }

    fun saveMeta(dir: File, m: Meta) {
        val p = Properties().apply { setProperty("name", m.appName); setProperty("package", m.pkg) }
        File(dir, META).outputStream().use { p.store(it, null) }
    }

    fun tree(project: File, expanded: Set<String>): List<Node> {
        val out = mutableListOf<Node>()
        fun walk(dir: File, depth: Int) {
            val kids = dir.listFiles()
                ?.filter { it.name != META && it.name != "__pycache__" }
                ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() })) ?: return
            for (k in kids) {
                val rel = k.relativeTo(project).invariantSeparatorsPath
                out += Node(k, rel, depth, k.isDirectory)
                if (k.isDirectory && rel in expanded) walk(k, depth + 1)
            }
        }
        walk(project, 0)
        return out
    }

    fun userFiles(project: File): List<File> =
        project.walkTopDown().filter { it.isFile && it.name != META && "__pycache__" !in it.path }.toList()

    private fun safe(project: File, rel: String): File {
        val f = File(project, rel).canonicalFile
        require(f.path.startsWith(project.canonicalPath + File.separator)) { "Недопустимый путь" }
        return f
    }

    fun newFile(project: File, rel: String) { val f = safe(project, rel); f.parentFile?.mkdirs(); f.createNewFile() }
    fun newFolder(project: File, rel: String) { safe(project, rel).mkdirs() }

    fun rename(project: File, node: Node, newName: String) {
        val parent = node.file.parentFile!!.relativeTo(project).invariantSeparatorsPath
        node.file.renameTo(safe(project, (parent + "/" + newName).trimStart('/')))
    }

    fun importFile(project: File, name: String, bytes: ByteArray) {
        val f = safe(project, name); f.parentFile?.mkdirs(); f.writeBytes(bytes)
    }

    fun exportZip(project: File, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            userFiles(project).forEach { f ->
                z.putNextEntry(ZipEntry(f.relativeTo(project).invariantSeparatorsPath))
                f.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
    }
}
