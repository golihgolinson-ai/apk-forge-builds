package com.studiopy

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import java.io.File

fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)

fun installApk(ctx: Context, apk: File) {
    if (!ctx.packageManager.canRequestPackageInstalls()) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    ctx.startActivity(
        Intent(Intent.ACTION_VIEW)
            .setDataAndType(uriFor(ctx, apk), "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

fun shareFile(ctx: Context, f: File, mime: String) {
    val i = Intent(Intent.ACTION_SEND).setType(mime)
        .putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    ctx.startActivity(Intent.createChooser(i, f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun humanSize(b: Long) = when {
    b > 1_048_576 -> "%.1f МБ".format(b / 1_048_576.0)
    b > 1024 -> "%.0f КБ".format(b / 1024.0)
    else -> "$b Б"
}

val TEXT_EXT = setOf("py", "txt", "json", "md", "xml", "html", "css", "js", "csv", "cfg", "ini", "yaml", "yml", "toml", "")
