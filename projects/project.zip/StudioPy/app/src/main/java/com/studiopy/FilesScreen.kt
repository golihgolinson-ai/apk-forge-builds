package com.studiopy

import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private sealed interface Dlg {
    data class NewFile(val prefix: String) : Dlg
    data class NewFolder(val prefix: String) : Dlg
    data class Rename(val node: Node) : Dlg
    data class Delete(val node: Node) : Dlg
}

private fun iconFor(n: Node) = if (n.isDir) "📁" else when (n.file.extension.lowercase()) {
    "py" -> "🐍"; "json" -> "🧾"; "md", "txt" -> "📝"; "png", "jpg", "jpeg", "webp" -> "🖼️"; else -> "📄"
}

@Composable
fun FilesScreen(app: AppState, project: File) {
    val ctx = LocalContext.current
    var expanded by remember(project) { mutableStateOf(setOf<String>()) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    val nodes = remember(app.version, expanded, project) { app.store.tree(project, expanded) }
    val meta = remember(app.version, project) { app.store.meta(project) }

    fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
    fun attempt(block: () -> Unit) = runCatching(block).onFailure { toast(it.message ?: "Ошибка") }.also { app.bump() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) attempt {
            val name = ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && i >= 0) c.getString(i) else null
            } ?: "imported.py"
            val bytes = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes() }
            app.store.importFile(project, name, bytes)
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(project.name, { app.back() })
        GradientBox(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text(meta.appName, color = Color.White, style = MaterialTheme.typography.titleMedium)
                Text(meta.pkg, color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button({ app.go(Screen.Console(project)) }, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Violet)) {
                        Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(4.dp)); Text("Запустить")
                    }
                    Button({ app.go(Screen.Build(project)) }, colors = ButtonDefaults.buttonColors(containerColor = Color.Black.copy(alpha = .35f), contentColor = Color.White)) {
                        Icon(Icons.Default.Android, null); Spacer(Modifier.width(4.dp)); Text("Собрать APK")
                    }
                }
            }
        }
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
            IconButton({ dlg = Dlg.NewFile("") }) { Icon(Icons.Default.NoteAdd, "Файл") }
            IconButton({ dlg = Dlg.NewFolder("") }) { Icon(Icons.Default.CreateNewFolder, "Папка") }
            IconButton({ picker.launch(arrayOf("*/*")) }) { Icon(Icons.Default.UploadFile, "Импорт") }
            IconButton({
                attempt {
                    val z = File(ctx.cacheDir, "${project.name}.zip")
                    app.store.exportZip(project, z); shareFile(ctx, z, "application/zip")
                }
            }) { Icon(Icons.Default.Archive, "ZIP") }
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)) {
            items(nodes, key = { it.rel }) { n ->
                NodeRow(
                    n, n.rel in expanded, Modifier.animateItem(),
                    onClick = {
                        if (n.isDir) expanded = if (n.rel in expanded) expanded - n.rel else expanded + n.rel
                        else if (n.file.extension.lowercase() in TEXT_EXT) app.go(Screen.Editor(project, n.file))
                        else toast("Бинарный файл — редактор не открывает")
                    },
                    onNewFile = { dlg = Dlg.NewFile(n.rel + "/") },
                    onNewFolder = { dlg = Dlg.NewFolder(n.rel + "/") },
                    onRename = { dlg = Dlg.Rename(n) },
                    onDelete = { dlg = Dlg.Delete(n) },
                )
            }
        }
    }

    when (val d = dlg) {
        is Dlg.NewFile -> NameDialog("Новый файл", d.prefix, "путь: pkg/utils.py", { dlg = null }) { v ->
            attempt { app.store.newFile(project, v) }; dlg = null
            if (v.contains('/')) expanded = expanded + v.substringBeforeLast('/')
        }
        is Dlg.NewFolder -> NameDialog("Новая папка", d.prefix, "путь: data/images", { dlg = null }) { v ->
            attempt { app.store.newFolder(project, v) }; dlg = null
            expanded = expanded + v.trimEnd('/')
        }
        is Dlg.Rename -> NameDialog("Переименовать", d.node.file.name, "Имя", { dlg = null }) { v ->
            attempt { app.store.rename(project, d.node, v) }; dlg = null
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null },
            title = { Text("Удалить «${d.node.file.name}»?") },
            confirmButton = { TextButton({ d.node.file.deleteRecursively(); app.bump(); dlg = null }) { Text("Удалить") } },
            dismissButton = { TextButton({ dlg = null }) { Text("Отмена") } },
        )
        null -> {}
    }
}

@Composable
private fun NodeRow(
    n: Node, open: Boolean, modifier: Modifier, onClick: () -> Unit,
    onNewFile: () -> Unit, onNewFolder: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit,
) {
    var menu by remember { mutableStateOf(false) }
    val rot by animateFloatAsState(if (open) 90f else 0f, label = "chev")
    Row(
        modifier.fillMaxWidth().rounded().clickable(onClick = onClick).padding(start = (n.depth * 18).dp, top = 2.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (n.isDir) Icon(Icons.Default.ChevronRight, null, Modifier.rotate(rot).size(20.dp))
        else Spacer(Modifier.width(20.dp))
        Text(iconFor(n), fontSize = 18.sp, modifier = Modifier.padding(horizontal = 8.dp))
        Text(n.file.name, Modifier.weight(1f).padding(vertical = 10.dp), style = MaterialTheme.typography.bodyLarge)
        Box {
            IconButton({ menu = true }) { Icon(Icons.Default.MoreVert, null) }
            DropdownMenu(menu, { menu = false }) {
                if (n.isDir) {
                    DropdownMenuItem({ Text("Файл здесь") }, { menu = false; onNewFile() })
                    DropdownMenuItem({ Text("Папка здесь") }, { menu = false; onNewFolder() })
                }
                DropdownMenuItem({ Text("Переименовать") }, { menu = false; onRename() })
                DropdownMenuItem({ Text("Удалить") }, { menu = false; onDelete() })
            }
        }
    }
}

private fun Modifier.rounded() = this.clip(RoundedCornerShape(12.dp))
