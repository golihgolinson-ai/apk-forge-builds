import io
import os
import runpy
import sys
import traceback


class _Out(io.TextIOBase):
    def __init__(self, sink, err=False):
        self.sink = sink
        self.err = err

    def write(self, s):
        if s:
            self.sink.append(s, self.err)
        return len(s or "")

    def flush(self):
        pass


def run(path, sink):
    root = os.path.dirname(path)
    old_out, old_err, old_path = sys.stdout, sys.stderr, list(sys.path)
    for name, mod in list(sys.modules.items()):
        f = getattr(mod, "__file__", None)
        if f and f.startswith(root):
            del sys.modules[name]
    sys.path.insert(0, root)
    os.chdir(root)
    sys.stdout, sys.stderr = _Out(sink), _Out(sink, True)
    try:
        runpy.run_path(path, run_name="__main__")
    except SystemExit:
        pass
    except BaseException:
        traceback.print_exc()
    finally:
        sys.stdout, sys.stderr = old_out, old_err
        sys.path[:] = old_path
