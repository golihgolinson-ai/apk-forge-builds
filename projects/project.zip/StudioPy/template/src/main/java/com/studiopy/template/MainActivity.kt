package com.studiopy.template

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.widget.ScrollView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File
import kotlin.concurrent.thread

class ConsoleSink(private val post: (String, Boolean) -> Unit) {
    fun append(text: String, err: Boolean) = post(text, err)
}

/** Оболочка: копирует assets/pyproject в filesDir и запускает main.py. */
class MainActivity : Activity() {
    private lateinit var tv: TextView
    private lateinit var scroll: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tv = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 13f
            setTextIsSelectable(true)
            setPadding(32, 96, 32, 32)
        }
        scroll = ScrollView(this).apply { addView(tv) }
        setContentView(scroll)

        if (!Python.isStarted()) Python.start(AndroidPlatform(this))
        val dst = File(filesDir, "pyproject")
        dst.deleteRecursively()
        copyAssets("pyproject", dst)

        val sink = ConsoleSink { text, _ ->
            runOnUiThread { tv.append(text); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
        }
        thread {
            Python.getInstance().getModule("runner").callAttr("run", File(dst, "main.py").path, sink)
        }
    }

    private fun copyAssets(src: String, dst: File) {
        val list = assets.list(src) ?: return
        if (list.isEmpty()) {
            dst.parentFile?.mkdirs()
            assets.open(src).use { i -> dst.outputStream().use { i.copyTo(it) } }
        } else {
            dst.mkdirs()
            list.forEach { copyAssets("$src/$it", File(dst, it)) }
        }
    }
}
