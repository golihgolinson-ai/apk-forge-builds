package com.pyapk.runner

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.util.zip.ZipInputStream

class MainActivity : Activity() {
    private lateinit var out: TextView
    private lateinit var btn: Button
    private var entry = "main.py"
    private var buildId = "0"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val cfg = try {
            JSONObject(assets.open("config.json").bufferedReader().use { it.readText() })
        } catch (e: Exception) { JSONObject() }
        title = cfg.optString("name", "Python App")
        entry = cfg.optString("entry", "main.py")
        buildId = cfg.optString("build", "0")

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        btn = Button(this).apply { text = "Запустить"; setOnClickListener { start() } }
        out = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f; setTextIsSelectable(true) }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(out)
        }
        root.addView(btn); root.addView(scroll)
        setContentView(root)
        start()
    }

    private fun start() {
        btn.isEnabled = false
        out.text = "Выполняется...\n"
        Thread {
            val result = try {
                val dir = prepare()
                Python.getInstance().getModule("runner_main")
                    .callAttr("run", dir.absolutePath, entry).toString()
            } catch (e: Throwable) { "Ошибка: $e" }
            runOnUiThread { out.text = result; btn.isEnabled = true }
        }.start()
    }

    /** Распаковывает project.zip (один раз на каждую сборку). */
    private fun prepare(): File {
        val base = File(filesDir, "app")
        val dir = File(base, "project")
        val stamp = File(base, "stamp")
        if (!dir.exists() || !stamp.exists() || stamp.readText() != buildId) {
            dir.deleteRecursively(); dir.mkdirs()
            unzip(assets.open("project.zip"), dir)
            stamp.writeText(buildId)
        }
        return dir
    }

    private fun unzip(input: InputStream, dest: File) {
        val root = dest.canonicalPath + File.separator
        ZipInputStream(input.buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val f = File(dest, e.name)
                if (!f.canonicalPath.startsWith(root)) throw SecurityException("Bad path: ${e.name}")
                if (e.isDirectory) f.mkdirs() else { f.parentFile?.mkdirs(); f.outputStream().use { zin.copyTo(it) } }
                e = zin.nextEntry
            }
        }
    }
}
