import contextlib, io, os, runpy, sys, traceback


def run(project_dir, entry):
    entry_path = os.path.join(project_dir, entry)
    for p in (os.path.dirname(entry_path), project_dir):
        if p not in sys.path:
            sys.path.insert(0, p)
    data_dir = os.path.join(os.path.dirname(project_dir), "data")
    os.makedirs(data_dir, exist_ok=True)
    os.environ["APP_DATA_DIR"] = data_dir
    os.chdir(project_dir)

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            runpy.run_path(entry_path, run_name="__main__")
        except SystemExit:
            pass
        except BaseException:
            traceback.print_exc()
    return buf.getvalue() or "(программа ничего не вывела)"
