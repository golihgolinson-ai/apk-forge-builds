plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.chaquo.python")
}
android {
    namespace = "com.pyapk.runner"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.pyapk.runner"
        minSdk = 24
        targetSdk = 28 // чтобы пересобранный APK не требовал выравнивания resources.arsc
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "x86_64") }
    }
    packaging { jniLibs { useLegacyPackaging = true } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
chaquopy {
    defaultConfig {
        version = "3.11"
        pip {
            // Библиотеки, доступные ВСЕМ собираемым приложениям. Добавляйте свои:
            install("requests")
        }
    }
}
