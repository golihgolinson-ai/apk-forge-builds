# PyApk Studio
Kotlin-приложение для телефона: ZIP/папка с Python-проектом (любая структура) -> подписанный APK.

Как устроено: модуль `runner` — шаблон APK (Kotlin + Chaquopy), он запускает Python-проект.
Модуль `builder` — приложение, в которое шаблон вшит как assets/template.apk. На телефоне оно
подменяет в шаблоне project.zip + config.json, подписывает (apksig) и предлагает установить.

Сборка самого PyApk Studio (один раз, на ПК):
1. Android Studio (JDK 17, SDK 34) + установленный Python 3 (нужен Chaquopy при сборке).
2. File -> Open -> эта папка, дождаться Sync.
3. Выбрать конфигурацию `builder` -> Run (шаблон соберётся автоматически).
Библиотеки для всех будущих приложений: runner/build.gradle.kts -> pip { install("...") }.
