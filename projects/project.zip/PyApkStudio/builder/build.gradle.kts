plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.pyapk.builder"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.pyapk.builder"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/*.kotlin_module", "META-INF/versions/**") } }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("com.android.tools.build:apksig:8.5.2")
}

// Кладём собранный шаблон (runner) в assets билдера как template.apk
val embedRunner = tasks.register<Copy>("embedRunner") {
    dependsOn(":runner:assembleDebug")
    from(project(":runner").layout.buildDirectory.dir("outputs/apk/debug"))
    include("*.apk")
    into(layout.projectDirectory.dir("src/main/assets"))
    rename { "template.apk" }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(embedRunner) }
