package com.pyapk.builder

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {

    private val reqZip = 1
    private val reqDir = 2

    private lateinit var nameEt: EditText
    private lateinit var entryEt: EditText
    private lateinit var buildBtn: Button
    private lateinit var installBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var logView: TextView

    private var inputZip: File? = null
    private var analysis: Packager.Analysis? = null
    private var apk: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        fun button(t: String, enabled: Boolean = true, f: () -> Unit) =
            Button(this).apply { text = t; isEnabled = enabled; setOnClickListener { f() } }
                .also { root.addView(it) }

        button("1. Выбрать ZIP с Python-проектом") { pickZip() }
        button("   или выбрать папку проекта") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), reqDir) }

        nameEt = EditText(this).apply { hint = "Название приложения" }
        entryEt = EditText(this).apply { hint = "Точка входа (например main.py)" }
        root.addView(nameEt); root.addView(entryEt)

        buildBtn = button("2. Собрать APK", false) { build() }
        installBtn = button("3. Установить", false) { install() }
        saveBtn = button("Сохранить в Загрузки", false) { saveToDownloads() }

        logView = TextView(this).apply { typeface = Typeface.MONOSPACE; textSize = 12f; setTextIsSelectable(true) }
        root.addView(logView)
        setContentView(ScrollView(this).apply { addView(root) })
        log("Выберите ZIP или папку с проектом. Структура любая.")
    }

    // ---------- выбор проекта ----------
    private fun pickZip() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/zip", "application/x-zip-compressed", "application/octet-stream"))
        }, reqZip)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        bg {
            val dst = File(cacheDir, "input.zip")
            val defaultName: String
            if (requestCode == reqZip) {
                contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { i.copyTo(it) } }
                defaultName = displayName(uri).removeSuffix(".zip")
            } else {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                defaultName = Packager.folderToZip(this, uri, dst)
            }
            val a = Packager.analyze(dst)
            inputZip = dst; analysis = a
            ui {
                nameEt.setText(defaultName)
                entryEt.setText(a.entry)
                buildBtn.isEnabled = true
                installBtn.isEnabled = false; saveBtn.isEnabled = false
                log("Файлов: ${a.files.size}, точка входа: ${a.entry}" +
                    if (a.prefix.isNotEmpty()) "\nУбрана обёртка: ${a.prefix}" else "")
            }
        }
    }

    // ---------- сборка ----------
    private fun build() {
        val a = analysis ?: return
        val zip = inputZip ?: return
        val name = nameEt.text.toString().ifBlank { "Python App" }
        val entry = entryEt.text.toString().trim().ifBlank { a.entry }
        if (entry !in a.files) { log("Файл '$entry' не найден в проекте"); return }
        buildBtn.isEnabled = false
        log("Сборка...")
        bg {
            val pz = File(cacheDir, "project.zip")
            Packager.buildProjectZip(zip, a.prefix, pz)
            val slug = name.replace(Regex("[^A-Za-z0-9А-Яа-я_-]"), "_")
            val out = File(cacheDir, "apk/$slug.apk")
            Packager.buildApk(this, pz, entry, name, out)
            apk = out
            ui {
                log("Готово: ${out.name} (${out.length() / 1024} КБ)")
                buildBtn.isEnabled = true; installBtn.isEnabled = true; saveBtn.isEnabled = true
            }
        }
    }

    private fun install() {
        val f = apk ?: return
        if (!packageManager.canRequestPackageInstalls()) {
            log("Разрешите установку из этого источника и нажмите «Установить» снова")
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.files", f)
        startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun saveToDownloads() {
        val f = apk ?: return
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
        if (uri == null) { log("Не удалось сохранить"); return }
        contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
        log("Сохранено в Загрузки: ${f.name}")
    }

    // ---------- утилиты ----------
    private fun displayName(uri: Uri): String =
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "app"

    private fun bg(block: () -> Unit) = Thread {
        try { block() } catch (e: Throwable) { ui { log("Ошибка: $e"); buildBtn.isEnabled = analysis != null } }
    }.start()

    private fun ui(block: () -> Unit) = runOnUiThread(block)
    private fun log(s: String) { logView.append(s + "\n") }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
