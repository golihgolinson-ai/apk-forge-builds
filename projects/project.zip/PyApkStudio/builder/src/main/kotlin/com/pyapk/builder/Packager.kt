package com.pyapk.builder

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.android.apksig.ApkSigner
import org.json.JSONObject
import java.io.File
import java.security.KeyFactory
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

object Packager {

    data class Analysis(val prefix: String, val files: List<String>, val entry: String)

    private val IGNORED = setOf(
        ".git", "__pycache__", ".venv", "venv", ".idea", ".vscode",
        "node_modules", ".mypy_cache", "__MACOSX"
    )

    fun isIgnored(path: String) = path.split('/').any { it in IGNORED } || path.endsWith(".pyc")

    /** Папка (SAF tree) -> zip в кэше. Возвращает имя папки. */
    fun folderToZip(ctx: Context, tree: Uri, out: File): String {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: error("Нет доступа к папке")
        ZipOutputStream(out.outputStream().buffered()).use { zo ->
            fun walk(d: DocumentFile, path: String) {
                for (f in d.listFiles()) {
                    val n = f.name ?: continue
                    val p = if (path.isEmpty()) n else "$path/$n"
                    if (isIgnored(p)) continue
                    if (f.isDirectory) walk(f, p)
                    else {
                        zo.putNextEntry(ZipEntry(p))
                        ctx.contentResolver.openInputStream(f.uri)?.use { it.copyTo(zo) }
                        zo.closeEntry()
                    }
                }
            }
            walk(root, "")
        }
        return root.name ?: "app"
    }

    /** Любая структура: убирает общую корневую папку, ищет точку входа. */
    fun analyze(zip: File): Analysis {
        val names = ZipFile(zip).use { z ->
            z.entries().asSequence().filter { !it.isDirectory }.map { it.name }
                .filterNot(::isIgnored).toList()
        }
        require(names.isNotEmpty()) { "Архив пуст" }

        var prefix = ""
        while (true) {
            val rest = names.map { it.removePrefix(prefix) }
            if (!rest.all { '/' in it }) break
            val tops = rest.map { it.substringBefore('/') }.toSet()
            if (tops.size != 1) break
            val top = tops.first()
            if ("$prefix$top/__init__.py" in names) break // это пакет, не обёртка
            prefix += "$top/"
        }
        val files = names.map { it.removePrefix(prefix) }
        return Analysis(prefix, files, detectEntry(zip, prefix, files))
    }

    private fun detectEntry(zip: File, prefix: String, files: List<String>): String {
        val py = files.filter { it.endsWith(".py") }
        require(py.isNotEmpty()) { "В проекте нет .py файлов" }
        for (c in listOf("main.py", "app.py", "run.py", "start.py", "__main__.py", "src/main.py", "src/app.py"))
            if (c in py) return c
        val rx = Regex("""__name__\s*==\s*["']__main__["']""")
        val sorted = py.sortedBy { p -> p.count { it == '/' } }
        ZipFile(zip).use { z ->
            for (f in sorted) {
                val e = z.getEntry(prefix + f) ?: continue
                if (e.size > 1_000_000) continue
                if (rx.containsMatchIn(z.getInputStream(e).bufferedReader().readText())) return f
            }
        }
        return sorted.first()
    }

    /** Нормализованный project.zip (без корневой обёртки и мусора). */
    fun buildProjectZip(zip: File, prefix: String, out: File) {
        ZipFile(zip).use { z ->
            ZipOutputStream(out.outputStream().buffered()).use { zo ->
                for (e in z.entries()) {
                    if (e.isDirectory || isIgnored(e.name) || !e.name.startsWith(prefix)) continue
                    zo.putNextEntry(ZipEntry(e.name.removePrefix(prefix)))
                    z.getInputStream(e).copyTo(zo)
                    zo.closeEntry()
                }
            }
        }
    }

    /** Берёт template.apk, подменяет project.zip/config.json, подписывает. */
    fun buildApk(ctx: Context, projectZip: File, entry: String, appName: String, outApk: File) {
        val cache = ctx.cacheDir
        val template = File(cache, "template.apk")
        ctx.assets.open("template.apk").use { i -> template.outputStream().use { i.copyTo(it) } }

        val config = JSONObject()
            .put("name", appName).put("entry", entry)
            .put("build", System.currentTimeMillis().toString()).toString().toByteArray()

        val unsigned = File(cache, "unsigned.apk")
        ZipFile(template).use { tz ->
            ZipOutputStream(unsigned.outputStream().buffered()).use { zo ->
                for (e in tz.entries()) {
                    val n = e.name
                    if (n.startsWith("META-INF/") || n == "assets/project.zip" || n == "assets/config.json") continue
                    val ne = ZipEntry(n)
                    if (e.method == ZipEntry.STORED) {
                        ne.method = ZipEntry.STORED
                        ne.size = e.size; ne.compressedSize = e.size; ne.crc = e.crc
                    }
                    zo.putNextEntry(ne)
                    tz.getInputStream(e).use { it.copyTo(zo) }
                    zo.closeEntry()
                }
                zo.putNextEntry(ZipEntry("assets/project.zip"))
                projectZip.inputStream().use { it.copyTo(zo) }
                zo.closeEntry()
                zo.putNextEntry(ZipEntry("assets/config.json"))
                zo.write(config)
                zo.closeEntry()
            }
        }

        val key = KeyFactory.getInstance("RSA").generatePrivate(
            PKCS8EncodedKeySpec(ctx.assets.open("signing/key.pk8").use { it.readBytes() })
        )
        val cert = CertificateFactory.getInstance("X.509")
            .generateCertificate(ctx.assets.open("signing/cert.der")) as X509Certificate

        outApk.parentFile?.mkdirs()
        outApk.delete()
        ApkSigner.Builder(listOf(ApkSigner.SignerConfig.Builder("pyapk", key, listOf(cert)).build()))
            .setInputApk(unsigned)
            .setOutputApk(outApk)
            .setMinSdkVersion(24)
            .setV1SigningEnabled(true)
            .setV2SigningEnabled(true)
            .setV3SigningEnabled(false)
            .build()
            .sign()
        unsigned.delete(); template.delete()
    }
}
